
<?php
require_once 'koneksi.php';

// Wajib login
if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit;
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$idPesanan = (int) $_GET['id'];
$idUser = (int) $_SESSION['id_user'];

// Ambil pesanan milik user
$stmt = mysqli_prepare($conn, "
    SELECT * FROM pesanan
    WHERE id_pesanan = ? AND id_user = ?
");

mysqli_stmt_bind_param($stmt, "ii", $idPesanan, $idUser);
mysqli_stmt_execute($stmt);

$hasil = mysqli_stmt_get_result($stmt);
$pesanan = mysqli_fetch_assoc($hasil);

if (!$pesanan) {
    header("Location: index.php");
    exit;
}

// Ambil detail buku
$stmtDetail = mysqli_prepare($conn, "
    SELECT * FROM detail_pesanan
    WHERE id_pesanan = ?
");

mysqli_stmt_bind_param($stmtDetail, "i", $idPesanan);
mysqli_stmt_execute($stmtDetail);

$detail = mysqli_stmt_get_result($stmtDetail);

// Kode transaksi dan kode pesanan
$tanggalKode = date('dmy', strtotime($pesanan['dibuat_pada']));

$kodeTransaksi = 'LIT-' . $tanggalKode;

// Ambil tiga angka terakhir dari kode pesanan
$kodePesanan = substr($pesanan['kode_pesanan'], -3);

$modeCetak = isset($_GET['cetak']) && $_GET['cetak'] == '1';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struk Pesanan - LITERA</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 25px 15px;
            min-height: 100vh;
            background: rgba(73, 59, 89, .55);
            font-family: Arial, sans-serif;
            color: #493b59;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .receipt-container {
            width: 100%;
            max-width: 650px;
            margin: auto;
            position: relative;
        }

        .receipt {
            background: #fff;
            border: 1px solid #e8def2;
            border-radius: 15px;
            padding: 35px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, .15);
        }

        .close-button {
            position: absolute;
            top: -14px;
            right: -14px;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: #fff;
            color: #80639e;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 23px;
            box-shadow: 0 3px 12px rgba(0,0,0,.15);
        }

        .receipt-header {
            text-align: center;
            padding-bottom: 25px;
            border-bottom: 2px dashed #d9c8eb;
        }

        .receipt-logo {
            font-size: 31px;
            font-weight: bold;
            letter-spacing: 3px;
            color: #80639e;
        }

        .receipt-header p {
            color: #81718f;
            font-size: 13px;
            margin-top: 8px;
        }

        .receipt-title {
            text-align: center;
            margin: 25px 0;
        }

        .receipt-title h2 {
            font-size: 21px;
            margin-bottom: 7px;
        }

        .receipt-title span {
            font-size: 13px;
            color: #81718f;
        }

        .receipt-info {
            margin-bottom: 25px;
        }

        .receipt-info div {
            display: flex;
            justify-content: space-between;
            gap: 15px;
            margin-bottom: 12px;
            font-size: 13px;
        }

        .receipt-info span {
            color: #81718f;
            flex-shrink: 0;
        }

        .receipt-info strong {
            text-align: right;
            overflow-wrap: anywhere;
        }

        .receipt-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        .receipt-table th {
            background: #eee5f8;
            color: #493b59;
            padding: 12px 8px;
            font-size: 12px;
            text-align: left;
        }

        .receipt-table td {
            padding: 13px 8px;
            border-bottom: 1px solid #eee5f8;
            font-size: 12px;
        }

        .receipt-table th:last-child,
        .receipt-table td:last-child {
            text-align: right;
        }

        .receipt-total {
            border-top: 2px dashed #d9c8eb;
            padding-top: 20px;
            margin-top: 20px;
        }

        .receipt-total div {
            display: flex;
            justify-content: space-between;
            gap: 15px;
            margin-bottom: 12px;
            font-size: 14px;
        }

        .receipt-total .grand-total {
            color: #80639e;
            font-size: 20px;
            font-weight: bold;
        }

        .receipt-footer {
            text-align: center;
            border-top: 2px dashed #d9c8eb;
            margin-top: 25px;
            padding-top: 22px;
            color: #81718f;
            font-size: 13px;
            line-height: 1.7;
        }

        .receipt-actions {
            display: flex;
            justify-content: center;
            gap: 12px;
            margin-top: 22px;
            flex-wrap: wrap;
        }

        .receipt-actions a,
        .receipt-actions button {
            padding: 13px 22px;
            border-radius: 8px;
            border: none;
            text-decoration: none;
            font-weight: bold;
            cursor: pointer;
            font-size: 13px;
        }

        .print-button {
            background: #b69bd3;
            color: white;
        }

        .print-button:hover {
            background: #9e80c0;
        }

        .home-button {
            background: #eee5f8;
            color: #71578b;
        }

        @media(max-width: 500px) {
            .receipt {
                padding: 22px 15px;
            }

            .receipt-info div {
                font-size: 11px;
            }

            .receipt-table th,
            .receipt-table td {
                padding: 10px 5px;
                font-size: 10px;
            }

            .receipt-total .grand-total {
                font-size: 16px;
            }

            .close-button {
                right: 0;
                top: -43px;
            }
        }

        <?php if ($modeCetak): ?>
        body {
            background: white;
            padding: 0;
            display: block;
        }

        .receipt-container {
            max-width: 650px;
            margin: 20px auto;
        }

        .receipt {
            box-shadow: none;
            border: none;
        }

        .receipt-actions,
        .close-button {
            display: none !important;
        }
        <?php endif; ?>

        @media print {
            body {
                background: white !important;
                padding: 0;
                display: block;
            }

            .receipt-container {
                max-width: 100%;
                margin: 0;
            }

            .receipt {
                border: none;
                box-shadow: none;
                padding: 15px;
            }

            .receipt-actions,
            .close-button {
                display: none !important;
            }
        }
    </style>
</head>

<body>

<div class="receipt-container">

    <?php if (!$modeCetak): ?>
        <a href="index.php" class="close-button" title="Tutup">&times;</a>
    <?php endif; ?>

    <div class="receipt">

        <div class="receipt-header">
            <div class="receipt-logo">LITERA.</div>
            <p>Temukan Cerita, Temukan Makna.</p>
        </div>

        <div class="receipt-title">
            <h2>STRUK PEMBELIAN</h2>
            <span>Terima kasih sudah berbelanja di LITERA</span>
        </div>

        <div class="receipt-info">

            <div>
                <span>Nama Toko</span>
                <strong>LITERA BOOKSTORE</strong>
            </div>

            <div>
                <span>Tanggal</span>
                <strong><?= htmlspecialchars($tanggalKode); ?></strong>
            </div>

            <div>
                <span>Kode Transaksi</span>
                <strong><?= htmlspecialchars($kodeTransaksi); ?></strong>
            </div>

            <div>
                <span>Kode Pesanan</span>
                <strong><?= htmlspecialchars($kodePesanan); ?></strong>
            </div>

            <div>
                <span>Nama Pembeli</span>
                <strong><?= htmlspecialchars($_SESSION['nama'] ?? 'Pelanggan'); ?></strong>
            </div>

            <div>
                <span>Alamat Pengiriman</span>
                <strong><?= nl2br(htmlspecialchars($pesanan['alamat'])); ?></strong>
            </div>

            <div>
                <span>Metode Pembayaran</span>
                <strong><?= htmlspecialchars($pesanan['metode_pembayaran']); ?></strong>
            </div>

            <div>
                <span>Status Pesanan</span>
                <strong><?= htmlspecialchars($pesanan['status']); ?></strong>
            </div>

        </div>

        <table class="receipt-table">
            <thead>
                <tr>
                    <th>Buku</th>
                    <th>Jumlah</th>
                    <th>Subtotal</th>
                </tr>
            </thead>

            <tbody>

                <?php while ($buku = mysqli_fetch_assoc($detail)): ?>
                    <tr>
                        <td><?= htmlspecialchars($buku['judul_buku']); ?></td>
                        <td><?= (int) $buku['jumlah']; ?></td>
                        <td>
                            Rp<?= number_format($buku['subtotal'], 0, ',', '.'); ?>
                        </td>
                    </tr>
                <?php endwhile; ?>

            </tbody>
        </table>

        <div class="receipt-total">
            <div class="grand-total">
                <span>Total Pembayaran</span>
                <span>
                    Rp<?= number_format($pesanan['total'], 0, ',', '.'); ?>
                </span>
            </div>
        </div>

        <div class="receipt-footer">
            <strong>Terima kasih telah memilih LITERA.</strong>
            <br>
            Semoga buku yang kamu pilih membawa cerita dan inspirasi baru.
            <br>
            <strong>Happy Reading!</strong>
        </div>

    </div>

    <?php if (!$modeCetak): ?>
        <div class="receipt-actions">

            <button
                type="button"
                class="print-button"
                onclick="cetakStruk()">
                Cetak Struk
            </button>

            <a href="index.php" class="home-button">
                Kembali ke Beranda
            </a>

        </div>
    <?php endif; ?>

</div>

<?php if ($modeCetak): ?>
<script>
    window.onload = function () {
        window.print();
    };
</script>
<?php else: ?>
<script>
    function cetakStruk() {
        const url = 'struk.php?id=<?= $idPesanan; ?>&cetak=1';

        const popup = window.open(
            url,
            'CetakStruk',
            'width=850,height=750,scrollbars=yes,resizable=yes'
        );

        if (!popup) {
            alert('Pop-up diblokir browser. Izinkan pop-up untuk mencetak struk.');
        }
    }
</script>
<?php endif; ?>

</body>
</html>
