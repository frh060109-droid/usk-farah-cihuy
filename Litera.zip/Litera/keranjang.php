
<?php
require_once 'koneksi.php';

// Tambah buku ke keranjang
if (isset($_POST['tambah_keranjang'])) {
    if (!isset($_SESSION['id_user'])) {
        header("Location: login.php");
        exit;
    }

    $id_buku = (int) $_POST['id_buku'];
    $jumlah = max(1, (int) $_POST['jumlah']);

    $query = mysqli_query($conn, "SELECT stok FROM buku WHERE id_buku = $id_buku");
    $buku = mysqli_fetch_assoc($query);

    if ($buku && $buku['stok'] >= $jumlah) {
        if (!isset($_SESSION['keranjang'])) {
            $_SESSION['keranjang'] = [];
        }

        $jumlahLama = $_SESSION['keranjang'][$id_buku] ?? 0;
        $jumlahBaru = $jumlahLama + $jumlah;

        if ($jumlahBaru <= (int) $buku['stok']) {
            $_SESSION['keranjang'][$id_buku] = $jumlahBaru;
            $_SESSION['pesan_keranjang'] = "Buku berhasil ditambahkan ke keranjang!";
        } else {
            $_SESSION['pesan_keranjang'] = "Jumlah buku melebihi stok yang tersedia.";
        }
    }

    header("Location: keranjang.php");
    exit;
}

// Ubah jumlah buku
if (isset($_POST['ubah_jumlah'])) {
    $id_buku = (int) $_POST['id_buku'];
    $jumlah = max(1, (int) $_POST['jumlah']);

    $query = mysqli_query($conn, "SELECT stok FROM buku WHERE id_buku = $id_buku");
    $buku = mysqli_fetch_assoc($query);

    if ($buku && $jumlah <= (int) $buku['stok']) {
        $_SESSION['keranjang'][$id_buku] = $jumlah;
        $_SESSION['pesan_keranjang'] = "Jumlah buku berhasil diperbarui!";
    } else {
        $_SESSION['pesan_keranjang'] = "Jumlah buku melebihi stok yang tersedia.";
    }

    header("Location: keranjang.php");
    exit;
}

// Hapus buku
if (isset($_GET['hapus'])) {
    $id_buku = (int) $_GET['hapus'];
    unset($_SESSION['keranjang'][$id_buku]);

    header("Location: keranjang.php");
    exit;
}

// Ambil data keranjang
$keranjang = $_SESSION['keranjang'] ?? [];
$daftarBuku = [];
$total = 0;

if (!empty($keranjang)) {
    $ids = array_map('intval', array_keys($keranjang));
    $idList = implode(',', $ids);

    $query = mysqli_query($conn, "SELECT * FROM buku WHERE id_buku IN ($idList)");

    while ($buku = mysqli_fetch_assoc($query)) {
        $jumlah = (int) $keranjang[$buku['id_buku']];
        $subtotal = (float) $buku['harga'] * $jumlah;

        $buku['jumlah'] = $jumlah;
        $buku['subtotal'] = $subtotal;

        $daftarBuku[] = $buku;
        $total += $subtotal;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Keranjang - LITERA</title>
    <link rel="stylesheet" href="style.css?v=112">

    <style>
        .cart-page {
            background: #faf6ff;
            min-height: 85vh;
            padding: 55px 8%;
        }

        .cart-container {
            max-width: 1100px;
            margin: auto;
        }

        .cart-title {
            color: #493b59;
            font-size: 30px;
            margin-bottom: 28px;
        }

        .cart-message {
            background: #eee5f8;
            color: #71578b;
            padding: 14px 18px;
            border-radius: 9px;
            margin-bottom: 20px;
        }

        .cart-card {
            background: #fdfaff;
            border: 1px solid #e8def2;
            border-radius: 15px;
            padding: 22px;
            margin-bottom: 18px;
            display: grid;
            grid-template-columns: 115px 1fr auto;
            gap: 22px;
            align-items: center;
        }

        .cart-image {
            width: 115px;
            height: 145px;
            background: #eee5f8;
            border-radius: 9px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }

        .cart-image img {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }

        .cart-info h3 {
            color: #493b59;
            font-size: 19px;
            margin-bottom: 8px;
        }

        .cart-info p {
            color: #81718f;
            margin-bottom: 7px;
        }

        .cart-price {
            color: #9e80c0 !important;
            font-weight: bold;
        }

        .cart-quantity {
            display: flex;
            align-items: center;
            gap: 9px;
            margin-top: 13px;
        }

        .cart-quantity input {
            width: 85px;
            padding: 10px;
            border: 1px solid #d9c8eb;
            border-radius: 7px;
        }

        .update-button {
            background: #eee5f8;
            color: #71578b;
            border: none;
            padding: 10px 15px;
            border-radius: 7px;
            cursor: pointer;
        }

        .update-button:hover {
            background: #e3d5f2;
        }

        .cart-subtotal {
            text-align: right;
        }

        .cart-subtotal strong {
            display: block;
            color: #493b59;
            margin-bottom: 15px;
        }

        .delete-cart {
            color: #b36b91;
            text-decoration: none;
            font-size: 13px;
        }

        .cart-summary {
            background: #eee5f8;
            padding: 25px;
            border-radius: 13px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            margin-top: 25px;
        }

        .cart-summary h3 {
            color: #493b59;
        }

        .cart-total {
            color: #80639e;
            font-size: 24px;
            font-weight: bold;
        }

        .cart-actions {
            display: flex;
            gap: 12px;
            margin-top: 20px;
            flex-wrap: wrap;
        }

        .cart-button {
            padding: 13px 22px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
        }

        .continue-button {
            background: #eee5f8;
            color: #71578b;
        }

        .checkout-button {
            background: #b69bd3;
            color: white;
        }

        .checkout-button:hover {
            background: #9e80c0;
        }

        .empty-cart {
            background: #fdfaff;
            border: 1px solid #e8def2;
            border-radius: 15px;
            padding: 55px 20px;
            text-align: center;
        }

        .empty-cart .cart-icon {
            font-size: 55px;
            margin-bottom: 15px;
        }

        .empty-cart h2 {
            color: #493b59;
            margin-bottom: 10px;
        }

        .empty-cart p {
            color: #81718f;
            margin-bottom: 22px;
        }

        @media (max-width: 700px) {
            .cart-page {
                padding: 35px 5%;
            }

            .cart-card {
                grid-template-columns: 85px 1fr;
                gap: 14px;
                padding: 15px;
            }

            .cart-image {
                width: 85px;
                height: 115px;
            }

            .cart-subtotal {
                grid-column: 2;
                text-align: left;
            }
        }
    </style>
</head>

<body>

<header class="navbar">
    <div class="logo">LITERA.</div>

    <nav>
        <a href="index.php">Beranda</a>
        <a href="katalog.php">Katalog</a>
        <a href="keranjang.php">🛒 Keranjang</a>

        <?php if (isset($_SESSION['id_user'])): ?>
            <a href="profile.php">Profil</a>
            <a href="logout.php">Keluar</a>
        <?php else: ?>
            <a href="login.php">Masuk</a>
            <a href="register.php">Daftar</a>
        <?php endif; ?>
    </nav>
</header>

<main class="cart-page">
    <div class="cart-container">

        <h1 class="cart-title">Keranjang Belanja</h1>

        <?php if (isset($_SESSION['pesan_keranjang'])): ?>
            <div class="cart-message">
                <?= htmlspecialchars($_SESSION['pesan_keranjang']); ?>
            </div>
            <?php unset($_SESSION['pesan_keranjang']); ?>
        <?php endif; ?>

        <?php if (!empty($daftarBuku)): ?>

            <?php foreach ($daftarBuku as $buku): ?>

                <div class="cart-card">

                    <div class="cart-image">
                        <?php
                        $gambarFile = !empty($buku['gambar'])
                            ? basename(str_replace('\\', '/', $buku['gambar']))
                            : '';

                        $gambarPath = __DIR__ . '/uploads/' . $gambarFile;
                        $gambarUrl = 'uploads/' . rawurlencode($gambarFile);
                        ?>

                        <?php if ($gambarFile && is_file($gambarPath)): ?>
                            <img
                                src="<?= htmlspecialchars($gambarUrl); ?>"
                                alt="<?= htmlspecialchars($buku['judul']); ?>"
                            >
                        <?php else: ?>
                            <span>📚</span>
                        <?php endif; ?>
                    </div>

                    <div class="cart-info">

                        <h3><?= htmlspecialchars($buku['judul']); ?></h3>

                        <p><?= htmlspecialchars($buku['penulis']); ?></p>

                        <p class="cart-price">
                            Rp<?= number_format($buku['harga'], 0, ',', '.'); ?>
                        </p>

                        <form method="POST" class="cart-quantity">

                            <input type="hidden" name="id_buku"
                                value="<?= (int) $buku['id_buku']; ?>">

                            <input
                                type="number"
                                name="jumlah"
                                class="quantity-input"
                                value="<?= $buku['jumlah']; ?>"
                                min="1"
                                max="<?= (int) $buku['stok']; ?>"
                                data-price="<?= (float) $buku['harga']; ?>"
                                required
                            >

                            <button type="submit" name="ubah_jumlah"
                                class="update-button">
                                Ubah
                            </button>

                        </form>

                    </div>

                    <div class="cart-subtotal">

                        <strong class="item-subtotal">
                            Rp<?= number_format($buku['subtotal'], 0, ',', '.'); ?>
                        </strong>

                        <a class="delete-cart"
                            href="keranjang.php?hapus=<?= (int) $buku['id_buku']; ?>"
                            onclick="return confirm('Hapus buku dari keranjang?')">
                            Hapus
                        </a>

                    </div>

                </div>

            <?php endforeach; ?>

            <div class="cart-summary">

                <h3>Total Belanja</h3>

                <div class="cart-total" id="cart-total">
                    Rp<?= number_format($total, 0, ',', '.'); ?>
                </div>

            </div>

            <div class="cart-actions">

                <a href="katalog.php" class="cart-button continue-button">
                    Lanjut Belanja
                </a>

                <a href="checkout.php" class="cart-button checkout-button">
                    Checkout Sekarang
                </a>

            </div>

        <?php else: ?>

            <div class="empty-cart">

                <div class="cart-icon">🛒</div>

                <h2>Keranjang Belanja</h2>

                <p>Yuk, temukan buku favoritmu dan masukkan ke keranjang!</p>

                <a href="katalog.php" class="cart-button checkout-button">
                    Lihat Katalog
                </a>

            </div>

        <?php endif; ?>

    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const inputs = document.querySelectorAll('.quantity-input');
    const totalElement = document.getElementById('cart-total');

    function formatRupiah(angka) {
        return 'Rp' + Math.round(angka).toLocaleString('id-ID');
    }

    function hitungTotal() {

        let total = 0;

        inputs.forEach(function (input) {

            const harga = parseFloat(input.dataset.price) || 0;
            const jumlah = Math.max(1, parseInt(input.value) || 1);
            const subtotal = harga * jumlah;

            total += subtotal;

            const card = input.closest('.cart-card');
            const subtotalElement = card.querySelector('.item-subtotal');

            subtotalElement.textContent = formatRupiah(subtotal);

        });

        totalElement.textContent = formatRupiah(total);
    }

    inputs.forEach(function (input) {

        input.addEventListener('input', hitungTotal);

    });

});
</script>

</body>
</html>
