<?php
require_once 'koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$books = [

    // ================= NOVEL =================

    [
        '3726 mdpl', 'Nurwina Sari', 'Novel', 85000, 10,
        'Sebuah kisah yang membawa pembaca menyusuri perjalanan cinta, perjuangan, dan berbagai perasaan yang tumbuh di tengah perjalanan kehidupan. Cerita ini menghadirkan pengalaman tentang harapan, kenangan, serta arti sebuah perjalanan dalam menemukan makna hidup.',
        '3726 mdpl.jpg'
    ],
    [
        'Aroma Karsa', 'Dee Lestari', 'Novel', 125000, 10,
        'Novel ini mengikuti perjalanan Jati Wesi, seorang pemuda dengan kemampuan penciuman yang luar biasa. Ia terlibat dalam pencarian aroma legendaris yang menyimpan misteri besar. Kisahnya memadukan petualangan, sejarah, keluarga, dan rahasia masa lalu.',
        'Aroma Karsa.jpg'
    ],
    [
        'Cantik Itu Luka', 'Eka Kurniawan', 'Novel', 115000, 10,
        'Mengisahkan kehidupan Dewi Ayu dan keluarganya dalam latar sejarah Indonesia yang penuh perubahan. Novel ini menghadirkan cerita tentang cinta, kekuasaan, keluarga, dan berbagai peristiwa yang membentuk kehidupan para tokohnya.',
        'Cantik Itu Luka.jpg'
    ],
    [
        'Hujan', 'Tere Liye', 'Novel', 89000, 10,
        'Bercerita tentang Lail yang menjalani kehidupan di tengah dunia yang mengalami perubahan besar akibat bencana alam. Dalam perjalanan hidupnya, ia mengenal persahabatan, kehilangan, dan cinta. Novel ini mengajak pembaca memahami arti kenangan dan pilihan dalam kehidupan.',
        'Hujan (2).jpg'
    ],
    [
        'Laskar Pelangi', 'Andrea Hirata', 'Novel', 95000, 10,
        'Mengisahkan perjuangan sepuluh anak di Belitung yang memiliki semangat besar untuk mendapatkan pendidikan. Di tengah keterbatasan, mereka terus mengejar impian bersama guru-guru yang menginspirasi. Cerita ini menyampaikan pesan tentang persahabatan, pendidikan, dan pantang menyerah.',
        'Laskar Pelangi (2).jpg'
    ],
    [
        'Negeri 5 Menara', 'Ahmad Fuadi', 'Novel', 98000, 10,
        'Bercerita tentang perjalanan Alif dan teman-temannya dalam menempuh pendidikan di sebuah pesantren. Mereka belajar tentang persahabatan, kedisiplinan, dan perjuangan meraih cita-cita. Novel ini mengangkat semangat bahwa impian dapat dicapai melalui usaha dan keyakinan.',
        'Negeri 5 Menara.jpg'
    ],
    [
        'Perahu Kertas', 'Dee Lestari', 'Novel', 99000, 10,
        'Mengisahkan Kugy dan Keenan yang memiliki impian serta cara pandang berbeda terhadap kehidupan. Pertemuan mereka membawa cerita tentang cinta, persahabatan, dan perjalanan menemukan jati diri. Novel ini menggambarkan bahwa setiap orang memiliki jalan sendiri untuk mengejar impiannya.',
        'Perahu Kertas.jpg'
    ],
    [
        'Pulang', 'Tere Liye', 'Novel', 90000, 10,
        'Mengikuti perjalanan hidup Bujang yang tumbuh dalam lingkungan penuh tantangan. Ia harus menghadapi berbagai pilihan, konflik, dan perjalanan panjang untuk memahami arti keluarga serta kesetiaan. Ceritanya memadukan petualangan dan nilai kehidupan.',
        'Pulang.jpg'
    ],
    [
        'Rembulan Tenggelam di Wajahmu', 'Tere Liye', 'Novel', 95000, 10,
        'Mengisahkan perjalanan hidup seorang pria bernama Ray yang mendapatkan kesempatan untuk memahami kembali berbagai kejadian dalam hidupnya. Cerita ini membawa pembaca merenungkan tentang keluarga, cinta, kehilangan, dan alasan di balik setiap peristiwa.',
        'Rembulan Tenggelam di Wajahmu.jpg'
    ],
    [
        'Seporsi Mie Ayam Sebelum Kamu Mati', 'Brian Khrisna', 'Novel', 89000, 10,
        'Novel ini menghadirkan cerita tentang kehidupan, pertemuan, dan berbagai pengalaman manusia yang sering kali tidak terlihat oleh orang lain. Dengan pendekatan yang menyentuh, pembaca diajak memahami arti kepedulian, kesempatan, dan hal-hal sederhana dalam kehidupan.',
        'Seporsi Mie Ayam Sebelum Kamu Mati.jpg'
    ],

    // ============== PENGEMBANGAN DIRI ==============

    [
        'Atomic Habits', 'James Clear', 'Pengembangan Diri', 98000, 10,
        'Buku ini membahas bagaimana kebiasaan kecil yang dilakukan secara konsisten dapat membawa perubahan besar dalam kehidupan. James Clear menjelaskan cara membangun kebiasaan baik, mengurangi kebiasaan buruk, dan menciptakan sistem yang mendukung perkembangan diri. Cocok untuk pembaca yang ingin memperbaiki rutinitas sehari-hari.',
        'Atomic Habits.jpg'
    ],
    [
        'Filosofi Teras', 'Henry Manampiring', 'Pengembangan Diri', 85000, 10,
        'Buku ini memperkenalkan filosofi Stoisisme sebagai cara menghadapi kehidupan dengan lebih tenang. Pembaca diajak memahami hal-hal yang dapat dan tidak dapat dikendalikan serta belajar mengelola emosi. Penjelasannya ringan dengan contoh yang dekat dengan kehidupan sehari-hari.',
        'Filosofi Teras.jpg'
    ],
    [
        'Good Vibes, Good Life', 'Vex King', 'Pengembangan Diri', 95000, 10,
        'Buku ini mengajak pembaca untuk membangun hubungan yang lebih baik dengan diri sendiri. Pembahasannya mencakup rasa percaya diri, pikiran positif, penerimaan diri, dan pentingnya menjaga lingkungan yang mendukung. Buku ini cocok bagi pembaca yang ingin mengembangkan pola pikir lebih sehat.',
        'Good Vibes, Good Life.jpg'
    ],
    [
        'Sebuah Seni untuk Bersikap Bodo Amat', 'Mark Manson', 'Pengembangan Diri', 89000, 10,
        'Buku ini membahas cara menentukan hal-hal yang benar-benar penting dalam kehidupan. Mark Manson mengajak pembaca untuk menerima keterbatasan, menghadapi masalah, dan tidak terus-menerus mengejar kesempurnaan. Penyampaiannya santai dan menggunakan contoh yang dekat dengan kehidupan.',
        'Sebuah Seni untuk Bersikap Bodo Amat.jpg'
    ],
    [
        'The Psychology of Money', 'Morgan Housel', 'Pengembangan Diri', 105000, 10,
        'Buku ini menjelaskan hubungan antara perilaku manusia dan cara mengelola uang. Pembaca diajak memahami bahwa keputusan keuangan tidak hanya dipengaruhi oleh pengetahuan, tetapi juga pengalaman, kebiasaan, dan emosi. Terdapat berbagai pelajaran tentang menabung, kesabaran, dan pengambilan keputusan.',
        'The Psychology of Money.jpg'
    ],
    [
        'Berani Tidak Disukai', 'Ichiro Kishimi dan Fumitake Koga', 'Pengembangan Diri', 99000, 10,
        'Melalui percakapan antara seorang pemuda dan seorang filsuf, buku ini membahas pemikiran psikologi Alfred Adler. Pembaca diajak memahami kebebasan diri, hubungan sosial, dan pentingnya tidak selalu bergantung pada penilaian orang lain. Buku ini mendorong pembaca untuk lebih mengenal dirinya sendiri.',
        'Berani Tidak Disukai.jpg'
    ],
    [
        'The 5 AM Club', 'Robin Sharma', 'Pengembangan Diri', 110000, 10,
        'Buku ini membahas pentingnya rutinitas pagi dalam membantu seseorang mengembangkan potensi diri. Melalui cerita dan berbagai prinsip produktivitas, pembaca diajak mengatur waktu, menjaga fokus, dan membangun kebiasaan yang lebih terarah.',
        'The 5 AM Club.jpg'
    ],
    
    [
        'Grit', 'Angela Duckworth', 'Pengembangan Diri', 100000, 10,
        'Buku ini membahas pentingnya ketekunan dan semangat jangka panjang dalam mencapai tujuan. Angela Duckworth menjelaskan bahwa keberhasilan tidak hanya bergantung pada bakat, tetapi juga pada konsistensi dan kemauan untuk terus belajar. Ceritanya memberikan sudut pandang tentang arti perjuangan.',
        'Grit.jpg'
    ],
    [
        'The Power of Now', 'Eckhart Tolle', 'Pengembangan Diri', 115000, 10,
        'Buku ini mengajak pembaca untuk lebih menyadari kehidupan yang sedang dijalani saat ini. Pembahasannya berfokus pada kesadaran diri, pikiran, dan cara menghadapi berbagai pengalaman tanpa terus terjebak pada masa lalu maupun kekhawatiran masa depan.',
        'The Power of now.jpg'
    ],

    [
    'The Mountain Is You', 'Brianna Wiest', 'Pengembangan Diri', 99000, 10,
    'Buku ini membahas bagaimana seseorang dapat menghadapi hambatan yang berasal dari dalam dirinya sendiri. Brianna Wiest mengajak pembaca memahami pola perilaku, rasa takut, dan kebiasaan yang sering menghalangi perkembangan diri. Melalui pembahasan yang mendalam, pembaca diajak untuk mengenali diri sendiri, menerima perubahan, dan membangun kehidupan yang lebih baik. Buku ini cocok bagi siapa saja yang ingin berkembang dan memahami dirinya lebih jauh.',
    'The Mountain Is You.jpg'
],

    // ================= BISNIS =================

    [
        'Rich Dad Poor Dad', 'Robert T. Kiyosaki', 'Bisnis', 105000, 10,
        'Buku ini membahas perbedaan cara pandang terhadap uang dan pengelolaan keuangan melalui pengalaman dua sosok ayah dengan pemikiran berbeda. Pembaca diajak memahami aset, kewajiban, investasi, dan pentingnya pengetahuan finansial dalam mengambil keputusan.',
        'Rich Dad Poor Dad.jpg'
    ],
    [
        'Rework', 'Jason Fried dan David Heinemeier Hansson', 'Bisnis', 95000, 10,
        'Buku ini menawarkan sudut pandang berbeda dalam membangun dan menjalankan bisnis. Pembaca diajak untuk bekerja lebih sederhana, menghindari proses yang tidak diperlukan, dan mulai menjalankan ide tanpa harus menunggu semuanya sempurna.',
        'Rework.jpg'
    ],
    [
        'Start With Why', 'Simon Sinek', 'Bisnis', 110000, 10,
        'Buku ini membahas pentingnya memahami alasan di balik sebuah tindakan, organisasi, atau bisnis. Simon Sinek menjelaskan bagaimana tujuan yang jelas dapat membantu seseorang membangun kepercayaan dan menginspirasi orang lain. Cocok bagi pembaca yang tertarik pada kepemimpinan dan strategi bisnis.',
        'Start with Why.jpg'
    ],
    [
        'The $100 Startup', 'Chris Guillebeau', 'Bisnis', 99000, 10,
        'Buku ini membahas bagaimana seseorang dapat membangun usaha dari ide sederhana dengan modal yang relatif terbatas. Pembaca mendapatkan gambaran tentang menemukan peluang, memahami kebutuhan pelanggan, dan mengembangkan usaha berdasarkan kemampuan yang dimiliki.',
        'The $100 Startup.jpg'
    ],
    [
        'The Lean Startup', 'Eric Ries', 'Bisnis', 115000, 10,
        'Buku ini memperkenalkan pendekatan membangun bisnis dengan proses percobaan dan evaluasi secara berkelanjutan. Pembaca diajak menguji ide, memahami kebutuhan pelanggan, dan memperbaiki produk berdasarkan masukan. Pendekatan ini membantu bisnis berkembang dengan lebih terarah.',
        'The Lean Startup.jpg'
    ],
    [
        'Zero to One', 'Peter Thiel', 'Bisnis', 108000, 10,
        'Buku ini membahas cara menciptakan sesuatu yang baru dan membangun bisnis dengan keunikan tersendiri. Peter Thiel mengajak pembaca berpikir kreatif, melihat peluang, dan memahami pentingnya inovasi dalam dunia usaha.',
        'Zero to One.jpg'
    ],
    [
        'Think and Grow Rich', 'Napoleon Hill', 'Bisnis', 95000, 10,
        'Buku klasik ini membahas pola pikir, tujuan, dan ketekunan dalam mencapai kesuksesan. Pembaca diajak memahami pentingnya perencanaan, keyakinan, dan tindakan yang konsisten dalam mewujudkan tujuan pribadi maupun profesional.',
        'Think and Grow Rich.jpg'
    ],
    [
        'Good to Great', 'Jim Collins', 'Bisnis', 120000, 10,
        'Buku ini membahas berbagai faktor yang membantu sebuah perusahaan berkembang dari kondisi baik menjadi luar biasa. Pembahasannya mencakup kepemimpinan, budaya kerja, strategi, dan konsistensi dalam menjalankan tujuan perusahaan.',
        'Good To Great.jpg'
    ],

    [
        'Company of One', 'Paul Jarvis', 'Bisnis', 105000, 10,
        'Buku ini membahas konsep membangun bisnis yang tidak selalu harus berkembang menjadi perusahaan besar. Pembaca diajak memahami pentingnya keberlanjutan, efisiensi, dan kebebasan dalam menentukan arah usaha sesuai kebutuhan.',
        'Company of One.jpg'
    ]

];

// Pastikan folder uploads tersedia
$folderUpload = __DIR__ . '/uploads/';

if (!is_dir($folderUpload)) {
    mkdir($folderUpload, 0777, true);
}

$berhasil = 0;
$dilewati = 0;

$stmt = mysqli_prepare($conn, "
    INSERT INTO buku
    (judul, penulis, kategori, harga, stok, deskripsi, gambar, dibuat_pada)
    VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
");

foreach ($books as $book) {

    // Lewati judul yang sudah ada
    $cek = mysqli_prepare($conn, "SELECT id_buku FROM buku WHERE judul = ?");
    mysqli_stmt_bind_param($cek, "s", $book[0]);
    mysqli_stmt_execute($cek);
    mysqli_stmt_store_result($cek);

    if (mysqli_stmt_num_rows($cek) > 0) {
        $dilewati++;
        mysqli_stmt_close($cek);
        continue;
    }

    mysqli_stmt_close($cek);

    $gambar = $book[6];

    // Salin cover dari assets ke uploads
    if (!empty($gambar)) {
        $sumber = __DIR__ . '/assets/' . $gambar;
        $tujuan = $folderUpload . $gambar;

        if (file_exists($sumber)) {
            if (!file_exists($tujuan)) {
                copy($sumber, $tujuan);
            }
        } else {
            // Jika cover tidak ditemukan, simpan tanpa gambar
            $gambar = '';
        }
    }

    mysqli_stmt_bind_param(
        $stmt,
        "sssiiss",
        $book[0],
        $book[1],
        $book[2],
        $book[3],
        $book[4],
        $book[5],
        $gambar
    );

    if (mysqli_stmt_execute($stmt)) {
        $berhasil++;
    }
}

mysqli_stmt_close($stmt);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Buku LITERA</title>
</head>
<body style="font-family: Arial; padding: 30px; background: #FFF9EB; color: #55465F;">

    <h2>Data Buku LITERA Berhasil Diproses!</h2>

    <p>Buku berhasil ditambahkan: <strong><?= $berhasil; ?></strong></p>
    <p>Buku dilewati karena sudah ada: <strong><?= $dilewati; ?></strong></p>

    <p>Total koleksi yang disiapkan: 30 buku.</p>

    <a href="admin/buku.php">Lihat Kelola Buku</a>

</body>
</html>