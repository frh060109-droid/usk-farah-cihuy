<?php
require_once 'koneksi.php';

$chatBelum = 0;

if (isset($_SESSION['id_user']) && ($_SESSION['role'] ?? '') !== 'admin') {
    $id = (int) $_SESSION['id_user'];

    $queryChat = mysqli_query($conn, "
        SELECT COUNT(*) AS jumlah
        FROM chat_pesan
        WHERE id_user = $id
        AND pengirim = 'admin'
        AND dibaca = 0
    ");

    if ($queryChat) {
        $chatBelum = mysqli_fetch_assoc($queryChat)['jumlah'];
    }
}

// Mengambil 5 buku dengan penjualan terbanyak
$queryBestSeller = mysqli_query($conn, "
    SELECT
        b.*,
        SUM(dp.jumlah) AS total_terjual
    FROM detail_pesanan dp
    JOIN buku b ON dp.id_buku = b.id_buku
    JOIN pesanan p ON dp.id_pesanan = p.id_pesanan
    WHERE p.status != 'Dibatalkan'
    GROUP BY b.id_buku
    ORDER BY total_terjual DESC
    LIMIT 5
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LITERA - Temukan Buku Favoritmu</title>
    <link rel="stylesheet" href="style.css?v=10">

    <style>
        /* BUKU BEST SELLER */

        .best-seller {
            padding: 65px 8%;
            text-align: center;
        }

        .best-seller h2 {
            margin: 10px 0;
        }

        .best-seller-description {
            margin-bottom: 35px;
        }

        .best-seller-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 25px;
            max-width: 1100px;
            margin: 30px auto 0;
        }

        .best-seller-card {
            background: #fff;
            border-radius: 15px;
            padding: 18px;
            text-align: left;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.07);
            transition: 0.3s;
        }

        .best-seller-card:hover {
            transform: translateY(-5px);
        }

        .best-seller-card img {
            width: 100%;
            height: 220px;
            object-fit: contain;
            border-radius: 10px;
            margin-bottom: 15px;
        }

        .best-seller-card h3 {
            font-size: 16px;
            margin-bottom: 8px;
        }

        .best-seller-card .harga {
            font-weight: bold;
            margin-bottom: 8px;
        }

        .best-seller-card .terjual {
            font-size: 13px;
            color: #777;
            margin-bottom: 15px;
        }

        .best-seller-card a {
            display: inline-block;
            text-decoration: none;
            padding: 9px 15px;
            border-radius: 8px;
            background: #80639e;
            color: white;
            font-size: 13px;
        }

        .best-seller-card a:hover {
            background: #493b59;
        }

        .best-seller-empty {
            margin-top: 25px;
            color: #777;
        }

        @media (max-width: 600px) {
            .best-seller {
                padding: 45px 5%;
            }

            .best-seller-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 15px;
            }

            .best-seller-card {
                padding: 12px;
            }

            .best-seller-card img {
                height: 170px;
            }
        }
    </style>
</head>
<body>

<header class="navbar">
    <a href="index.php" class="logo">LITERA<span>.</span></a>

    <nav>
        <a href="index.php">Beranda</a>
        <a href="katalog.php">Katalog</a>
        <a href="#tentang">Tentang</a>
        <a href="#kontak">Kontak</a>

        <?php if (isset($_SESSION['id_user']) && ($_SESSION['role'] ?? '') !== 'admin'): ?>
            <a href="chat_admin.php">
                Contact Admin

                <?php if ($chatBelum > 0): ?>
                    <span style="color:#a85e5e;font-weight:bold;">
                        (<?= $chatBelum; ?>)
                    </span>
                <?php endif; ?>
            </a>
        <?php endif; ?>
    </nav>

    <div class="nav-button">
        <?php if (isset($_SESSION['id_user'])): ?>
            <a href="profile.php" class="btn-outline">Profil</a>
            <a href="logout.php" class="btn-primary">Keluar</a>
        <?php else: ?>
            <a href="login.php" class="btn-outline">Masuk</a>
            <a href="register.php" class="btn-primary">Daftar</a>
        <?php endif; ?>
    </div>
</header>

<main>

    <section class="hero">
        <div class="hero-content">
            <p class="eyebrow">SELAMAT DATANG DI LITERA</p>

            <h1>
                Setiap Buku Punya Cerita,
                <span>Temukan Ceritamu.</span>
            </h1>

            <p class="hero-description">
                Cari buku yang kamu suka dan temukan bacaan baru
                untuk menemani waktu luangmu.
            </p>

            <a href="katalog.php" class="btn-primary hero-button">
                Jelajahi Buku
            </a>
        </div>

        <div class="hero-decoration">
            <div class="decoration-circle"></div>

            <div class="book-card">
                <div class="book-cover">
                    <img src="assets/cover buku.jpg" alt="Cover Buku Litera">
                </div>
            </div>
        </div>
    </section>

    <!-- BUKU BEST SELLER -->
    <section class="best-seller">

        <p class="eyebrow">PALING BANYAK DIBELI</p>

        <h2>Buku Best Seller</h2>

        <p class="best-seller-description">
            Buku favorit yang paling banyak dibeli oleh pembaca LITERA.
        </p>

        <?php if ($queryBestSeller && mysqli_num_rows($queryBestSeller) > 0): ?>

            <div class="best-seller-grid">

                <?php while ($buku = mysqli_fetch_assoc($queryBestSeller)): ?>

                    <div class="best-seller-card">

                        <a href="detail_buku.php?id=<?= (int) $buku['id_buku']; ?>">
                            <img
                                src="uploads/<?= htmlspecialchars($buku['gambar']); ?>"
                                alt="<?= htmlspecialchars($buku['judul']); ?>"
                            >
                        </a>

                        <h3>
                            <?= htmlspecialchars($buku['judul']); ?>
                        </h3>

                        <p class="harga">
                            Rp<?= number_format($buku['harga'], 0, ',', '.'); ?>
                        </p>

                        <p class="terjual">
                            <?= (int) $buku['total_terjual']; ?> buku terjual
                        </p>

                        <a href="detail_buku.php?id=<?= (int) $buku['id_buku']; ?>">
                            Lihat Buku
                        </a>

                    </div>

                <?php endwhile; ?>

            </div>

        <?php else: ?>

            <p class="best-seller-empty">
                Belum ada buku yang terjual. Buku best seller akan muncul di sini.
            </p>

        <?php endif; ?>

    </section>

    <section class="intro" id="tentang">
        <p class="eyebrow">TENTANG LITERA</p>

        <h2>Temukan buku yang cocok <span>untukmu.</span></h2>

        <p>
            LITERA menyediakan berbagai pilihan buku untuk kamu
            yang suka membaca, belajar, atau sekadar mencari
            cerita baru.
        </p>
    </section>

    <section class="empty-catalog">
        <p class="eyebrow">KOLEKSI BUKU</p>

        <h2>Ada banyak cerita untuk ditemukan</h2>

        <p>
            Yuk, lihat berbagai pilihan buku yang tersedia
            di katalog LITERA.
        </p>

        <a href="katalog.php" class="btn-outline">Lihat Katalog</a>
    </section>

    <section class="kontak" id="kontak">
        <div class="kontak-container">

            <p class="kontak-label">LITERA BOOKSTORE</p>

            <h2>Hubungi Kami</h2>

            <p class="kontak-desc">
                Punya pertanyaan seputar buku atau pesanan?
                Hubungi kami melalui kontak berikut.
            </p>

            <div class="kontak-info">

                <div class="kontak-item">
                    <div class="kontak-icon">✉</div>
                    <h3>Email</h3>
                    <p>LITERA@gmail.com</p>

                    <a href="mailto:LITERA@gmail.com" class="kontak-btn">
                        Kirim Email
                    </a>
                </div>

                <div class="kontak-item">
                    <div class="kontak-icon">☎</div>
                    <h3>WhatsApp</h3>
                    <p>085756180799</p>

                    <a href="https://wa.me/6285756180799"
                       target="_blank" class="kontak-btn">
                        Hubungi Kami
                    </a>
                </div>

            </div>

            <div class="faq">
                <h3>Pertanyaan Umum</h3>

                <details class="faq-item">
                    <summary>Bagaimana cara membeli buku?</summary>
                    <p>
                        Pilih buku yang kamu mau, masukkan ke keranjang,
                        lalu lanjutkan ke checkout.
                    </p>
                </details>

                <details class="faq-item">
                    <summary>Apakah harus login untuk membeli buku?</summary>
                    <p>
                        Iya, kamu perlu login sebelum melakukan checkout.
                    </p>
                </details>

                <details class="faq-item">
                    <summary>Apa saja metode pembayarannya?</summary>
                    <p>
                        Kamu bisa melakukan pembayaran melalui transfer bank.
                    </p>
                </details>

                <details class="faq-item">
                    <summary>Bagaimana cara melihat status pesanan?</summary>
                    <p>
                        Status pesanan bisa dilihat melalui menu
                        Riway