
<?php
require_once 'koneksi.php';

// Pastikan user sudah login
if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit;
}

// Pastikan request berasal dari form checkout
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: keranjang.php");
    exit;
}

// Pastikan keranjang tidak kosong
$keranjang = $_SESSION['keranjang'] ?? [];

if (empty($keranjang)) {
    header("Location: keranjang.php");
    exit;
}

// Ambil data checkout
$nama = trim($_POST['nama_penerima'] ?? '');
$telepon = trim($_POST['telepon'] ?? '');
$alamat = trim($_POST['alamat'] ?? '');
$catatan = trim($_POST['catatan'] ?? '');
$metode = $_POST['metode_pembayaran'] ?? '';

// Validasi data pengiriman
if ($nama === '' || $telepon === '' || $alamat === '') {
    $_SESSION['error_checkout'] = "Lengkapi data pengiriman terlebih dahulu.";
    header("Location: checkout.php");
    exit;
}

// Hanya menerima Transfer Bank
if ($metode !== 'Transfer Bank') {
    $_SESSION['error_checkout'] = "Metode pembayaran hanya tersedia melalui Transfer Bank.";
    header("Location: checkout.php");
    exit;
}

// Ongkir tetap
$ongkir = 10000;

// Validasi bukti pembayaran
$buktiPembayaran = null;
$uploadPath = null;

if (
    !isset($_FILES['bukti_pembayaran']) ||
    $_FILES['bukti_pembayaran']['error'] !== UPLOAD_ERR_OK
) {
    $_SESSION['error_checkout'] = "Silakan upload bukti pembayaran transfer.";
    header("Location: checkout.php");
    exit;
}

// Maksimal ukuran file 2 MB
if ($_FILES['bukti_pembayaran']['size'] > 2 * 1024 * 1024) {
    $_SESSION['error_checkout'] = "Ukuran bukti pembayaran maksimal 2 MB.";
    header("Location: checkout.php");
    exit;
}

// Validasi format gambar
$tmpFile = $_FILES['bukti_pembayaran']['tmp_name'];
$mime = mime_content_type($tmpFile);

$allowedTypes = [
    'image/jpeg' => 'jpg',
    'image/png' => 'png',
    'image/webp' => 'webp'
];

if (!isset($allowedTypes[$mime])) {
    $_SESSION['error_checkout'] = "Format bukti pembayaran harus JPG, PNG, atau WEBP.";
    header("Location: checkout.php");
    exit;
}

// Validasi ID dan jumlah buku
foreach ($keranjang as $id => $jumlah) {
    if (
        !ctype_digit((string) $id) ||
        !is_numeric($jumlah) ||
        (int) $jumlah < 1
    ) {
        $_SESSION['error_checkout'] = "Data keranjang tidak valid.";
        header("Location: keranjang.php");
        exit;
    }
}

// Upload bukti pembayaran
$folderUpload = __DIR__ . '/uploads/';

if (!is_dir($folderUpload)) {
    mkdir($folderUpload, 0755, true);
}

$namaFile = 'bukti_' . bin2hex(random_bytes(12)) . '.' . $allowedTypes[$mime];
$uploadPath = $folderUpload . $namaFile;

if (!move_uploaded_file($tmpFile, $uploadPath)) {
    $_SESSION['error_checkout'] = "Bukti pembayaran gagal diunggah.";
    header("Location: checkout.php");
    exit;
}

$buktiPembayaran = $namaFile;

// Mulai transaksi database
mysqli_begin_transaction($conn);

try {

    $total = 0;
    $daftarBuku = [];

    // Mengunci data stok buku
    $stmtBuku = mysqli_prepare(
        $conn,
        "SELECT id_buku, judul, harga, stok
         FROM buku
         WHERE id_buku = ?
         FOR UPDATE"
    );

    foreach ($keranjang as $id => $jumlah) {

        $idBuku = (int) $id;
        $jumlah = (int) $jumlah;

        mysqli_stmt_bind_param($stmtBuku, "i", $idBuku);
        mysqli_stmt_execute($stmtBuku);

        $hasil = mysqli_stmt_get_result($stmtBuku);
        $buku = mysqli_fetch_assoc($hasil);

        if (!$buku) {
            throw new Exception("Buku tidak ditemukan.");
        }

        if ((int) $buku['stok'] < $jumlah || (int) $buku['stok'] <= 0) {
            throw new Exception(
                "Stok buku " . $buku['judul'] . " tidak mencukupi."
            );
        }

        $subtotal = (float) $buku['harga'] * $jumlah;
        $total += $subtotal;

        $buku['jumlah'] = $jumlah;
        $buku['subtotal'] = $subtotal;

        $daftarBuku[] = $buku;
    }

    // Total akhir = subtotal buku + ongkir
    $total += $ongkir;

    // Membuat kode transaksi berdasarkan tanggal
    $tanggalKode = date('dmy');

    // Mengambil nomor urut pesanan pada tanggal yang sama
    $stmtNomor = mysqli_prepare(
        $conn,
        "SELECT COUNT(*) AS total
         FROM pesanan
         WHERE DATE(dibuat_pada) = CURDATE()"
    );

    mysqli_stmt_execute($stmtNomor);
    $hasilNomor = mysqli_stmt_get_result($stmtNomor);
    $dataNomor = mysqli_fetch_assoc($hasilNomor);

    $nomorUrut = (int) $dataNomor['total'] + 1;

    // Format: LIT-DDMMYY001
    $kodePesanan = 'LIT-' . $tanggalKode .
        str_pad($nomorUrut, 3, '0', STR_PAD_LEFT);

    // Status awal pesanan
    $status = 'Menunggu Pembayaran';

    // Menyimpan data pesanan termasuk ongkir
    $stmtPesanan = mysqli_prepare(
        $conn,
        "INSERT INTO pesanan
        (id_user, kode_pesanan, total, ongkir, metode_pembayaran,
         status, bukti_pembayaran, alamat, catatan, dibuat_pada)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())"
    );

    $idUser = (int) $_SESSION['id_user'];

    mysqli_stmt_bind_param(
        $stmtPesanan,
        "isdisssss",
        $idUser,
        $kodePesanan,
        $total,
        $ongkir,
        $metode,
        $status,
        $buktiPembayaran,
        $alamat,
        $catatan
    );

    if (!mysqli_stmt_execute($stmtPesanan)) {
        throw new Exception("Pesanan gagal disimpan.");
    }

    $idPesanan = mysqli_insert_id($conn);

    // Menyimpan detail buku
    $stmtDetail = mysqli_prepare(
        $conn,
        "INSERT INTO detail_pesanan
        (id_pesanan, id_buku, judul_buku, harga, jumlah, subtotal)
        VALUES (?, ?, ?, ?, ?, ?)"
    );

    // Mengurangi stok buku
    $stmtStok = mysqli_prepare(
        $conn,
        "UPDATE buku
         SET stok = stok - ?
         WHERE id_buku = ? AND stok >= ?"
    );

    foreach ($daftarBuku as $buku) {

        $idBuku = (int) $buku['id_buku'];
        $judul = $buku['judul'];
        $harga = (float) $buku['harga'];
        $jumlah = (int) $buku['jumlah'];
        $subtotal = (float) $buku['subtotal'];

        mysqli_stmt_bind_param(
            $stmtDetail,
            "iisdid",
            $idPesanan,
            $idBuku,
            $judul,
            $harga,
            $jumlah,
            $subtotal
        );

        if (!mysqli_stmt_execute($stmtDetail)) {
            throw new Exception("Detail pesanan gagal disimpan.");
        }

        mysqli_stmt_bind_param(
            $stmtStok,
            "iii",
            $jumlah,
            $idBuku,
            $jumlah
        );

        if (
            !mysqli_stmt_execute($stmtStok) ||
            mysqli_stmt_affected_rows($stmtStok) !== 1
        ) {
            throw new Exception("Stok buku gagal diperbarui.");
        }
    }

    // Simpan semua perubahan
    mysqli_commit($conn);

    // Kosongkan keranjang
    unset($_SESSION['keranjang']);

    // Simpan ID pesanan untuk halaman struk
    $_SESSION['pesanan_terakhir'] = $idPesanan;

    header("Location: struk.php?id=" . $idPesanan);
    exit;

} catch (Throwable $e) {

    mysqli_rollback($conn);

    // Hapus bukti pembayaran jika transaksi gagal
    if ($uploadPath && file_exists($uploadPath)) {
        unlink($uploadPath);
    }

    $_SESSION['error_checkout'] = $e->getMessage();

    header("Location: checkout.php");
    exit;
}
?>
