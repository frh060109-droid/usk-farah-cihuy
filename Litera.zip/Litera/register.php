
<?php
require_once 'koneksi.php';

$pesan = "";
$jenis_pesan = "";

if (isset($_POST['daftar'])) {
    $nama = trim($_POST['nama']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $konfirmasi = $_POST['konfirmasi'];

    if (empty($nama) || empty($email) || empty($password) || empty($konfirmasi)) {
        $pesan = "Semua kolom harus diisi.";
        $jenis_pesan = "error";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $pesan = "Format email tidak valid.";
        $jenis_pesan = "error";
    } elseif (strlen($password) < 6) {
        $pesan = "Password minimal 6 karakter.";
        $jenis_pesan = "error";
    } elseif ($password !== $konfirmasi) {
        $pesan = "Konfirmasi password tidak sesuai.";
        $jenis_pesan = "error";
    } else {
        $cek = mysqli_prepare($conn, "SELECT id_user FROM users WHERE email = ?");
        mysqli_stmt_bind_param($cek, "s", $email);
        mysqli_stmt_execute($cek);
        mysqli_stmt_store_result($cek);

        if (mysqli_stmt_num_rows($cek) > 0) {
            $pesan = "Email sudah digunakan.";
            $jenis_pesan = "error";
        } else {
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $role = "user";

            $insert = mysqli_prepare(
                $conn,
                "INSERT INTO users (nama, email, password, role, dibuat_pada)
                 VALUES (?, ?, ?, ?, NOW())"
            );

            mysqli_stmt_bind_param(
                $insert,
                "ssss",
                $nama,
                $email,
                $password_hash,
                $role
            );

            if (mysqli_stmt_execute($insert)) {
                $pesan = "Akun berhasil dibuat. Silakan masuk.";
                $jenis_pesan = "success";
            } else {
                $pesan = "Pendaftaran gagal. Coba lagi.";
                $jenis_pesan = "error";
            }

            mysqli_stmt_close($insert);
        }

        mysqli_stmt_close($cek);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Akun - LITERA</title>
    <link rel="stylesheet" href="./style.css?v=10">

    <style>
        .password-field {
            position: relative;
            width: 100%;
        }

        .password-field input {
            width: 100%;
            padding-right: 48px !important;
        }

        .toggle-password {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            border: none;
            background: transparent;
            padding: 5px;
            cursor: pointer;
            color: #80639e;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .toggle-password svg {
            width: 20px;
            height: 20px;
            fill: none;
            stroke: currentColor;
            stroke-width: 1.8;
            stroke-linecap: round;
            stroke-linejoin: round;
        }

        .toggle-password .eye-off {
            display: none;
        }

        .toggle-password.password-visible .eye {
            display: none;
        }

        .toggle-password.password-visible .eye-off {
            display: block;
        }
    </style>
</head>
<body>

<header class="navbar">
    <a href="index.php" class="logo">LITERA<span>.</span></a>

    <nav>
        <a href="index.php">Beranda</a>
        <a href="katalog.php">Katalog</a>
        <a href="index.php#tentang">Tentang</a>
    </nav>

    <div class="nav-button">
        <a href="login.php" class="btn-outline">Masuk</a>
    </div>
</header>

<main class="auth-page">
    <div class="auth-card">

        <div class="auth-heading">
            <p class="eyebrow">SELAMAT DATANG DI LITERA</p>
            <h1>Buat Akun <span>Barumu.</span></h1>
            <p>Daftar dulu untuk mulai menjelajahi buku di LITERA.</p>
        </div>

        <?php if (!empty($pesan)): ?>
            <div class="auth-message <?php echo $jenis_pesan; ?>">
                <?php echo htmlspecialchars($pesan); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">

            <div class="form-group">
                <label>Nama Lengkap</label>
                <input
                    type="text"
                    name="nama"
                    placeholder="Masukkan nama lengkap"
                    value="<?php echo htmlspecialchars($_POST['nama'] ?? ''); ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label>Email</label>
                <input
                    type="email"
                    name="email"
                    placeholder="Masukkan email"
                    value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label>Password</label>

                <div class="password-field">
                    <input
                        type="password"
                        name="password"
                        id="password-daftar"
                        placeholder="Minimal 6 karakter"
                        required
                    >

                    <button
                        type="button"
                        class="toggle-password"
                        onclick="togglePassword('password-daftar', this)"
                        aria-label="Tampilkan password"
                    >
                        <svg class="eye" viewBox="0 0 24 24">
                            <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/>
                            <circle cx="12" cy="12" r="3"/>
                        </svg>

                        <svg class="eye-off" viewBox="0 0 24 24">
                            <path d="m3 3 18 18"/>
                            <path d="M10.6 10.6a2 2 0 0 0 2.8 2.8"/>
                            <path d="M9.9 5.2A10.8 10.8 0 0 1 12 5c6.5 0 10 7 10 7a15 15 0 0 1-3 3.8"/>
                            <path d="M6.2 6.2C3.5 8 2 12 2 12s3.5 7 10 7a10 10 0 0 0 4-.8"/>
                        </svg>
                    </button>
                </div>
            </div>

            <div class="form-group">
                <label>Konfirmasi Password</label>

                <div class="password-field">
                    <input
                        type="password"
                        name="konfirmasi"
                        id="password-konfirmasi"
                        placeholder="Masukkan ulang password"
                        required
                    >

                    <button
                        type="button"
                        class="toggle-password"
                        onclick="togglePassword('password-konfirmasi', this)"
                        aria-label="Tampilkan password"
                    >
                        <svg class="eye" viewBox="0 0 24 24">
                            <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/>
                            <circle cx="12" cy="12" r="3"/>
                        </svg>

                        <svg class="eye-off" viewBox="0 0 24 24">
                            <path d="m3 3 18 18"/>
                            <path d="M10.6 10.6a2 2 0 0 0 2.8 2.8"/>
                            <path d="M9.9 5.2A10.8 10.8 0 0 1 12 5c6.5 0 10 7 10 7a15 15 0 0 1-3 3.8"/>
                            <path d="M6.2 6.2C3.5 8 2 12 2 12s3.5 7 10 7a10 10 0 0 0 4-.8"/>
                        </svg>
                    </button>
                </div>
            </div>

            <button type="submit" name="daftar" class="auth-button">
                Daftar Sekarang
            </button>

        </form>

        <p class="auth-switch">
            Sudah punya akun?
            <a href="login.php">Masuk di sini</a>
        </p>

    </div>
</main>

<footer>
    <a href="index.php" class="logo">LITERA<span>.</span></a>
    <p>Temukan bacaan favoritmu di sini.</p>
    <small>© 2026 LITERA. Semua hak dilindungi.</small>
</footer>

<script>
function togglePassword(id, tombol) {
    const input = document.getElementById(id);

    if (input.type === "password") {
        input.type = "text";
        tombol.classList.add("password-visible");
        tombol.setAttribute("aria-label", "Sembunyikan password");
    } else {
        input.type = "password";
        tombol.classList.remove("password-visible");
        tombol.setAttribute("aria-label", "Tampilkan password");
    }
}
</script>

</body>
</html>
