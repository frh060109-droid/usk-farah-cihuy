
<?php
require_once 'koneksi.php';

if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit;
}

$id_user = (int) $_SESSION['id_user'];
$pesan = "";

// Ambil data profil pengguna
$query = mysqli_prepare($conn, "
    SELECT nama, email, dibuat_pada
    FROM users
    WHERE id_user = ?
");
mysqli_stmt_bind_param($query, "i", $id_user);
mysqli_stmt_execute($query);
$hasil = mysqli_stmt_get_result($query);
$user = mysqli_fetch_assoc($hasil);

if (!$user) {
    header("Location: logout.php");
    exit;
}

// Konfirmasi pesanan diterima oleh pembeli
if (isset($_POST['konfirmasi_pesanan']) && isset($_POST['id_pesanan'])) {

    $idPesanan = (int) $_POST['id_pesanan'];

    $stmtKonfirmasi = mysqli_prepare($conn, "
        UPDATE pesanan
        SET status = 'Selesai'
        WHERE id_pesanan = ?
        AND id_user = ?
        AND TRIM(status) = 'Diantar'
    ");

    if ($stmtKonfirmasi) {
        mysqli_stmt_bind_param(
            $stmtKonfirmasi,
            "ii",
            $idPesanan,
            $id_user
        );

        if (mysqli_stmt_execute($stmtKonfirmasi)) {
            if (mysqli_stmt_affected_rows($stmtKonfirmasi) > 0) {
                header("Location: profile.php?konfirmasi=berhasil");
                exit;
            } else {
                $pesan = "Pesanan tidak dapat dikonfirmasi. Pastikan status sudah Diantar dan pesanan tersebut milik akunmu.";
            }
        } else {
            $pesan = "Gagal memperbarui status pesanan.";
        }

        mysqli_stmt_close($stmtKonfirmasi);
    } else {
        $pesan = "Terjadi kesalahan saat memproses pesanan.";
    }
}

// Ambil pesanan khusus akun yang sedang login
$stmtPesanan = mysqli_prepare($conn, "
    SELECT *
    FROM pesanan
    WHERE id_user = ?
    ORDER BY dibuat_pada DESC
");

mysqli_stmt_bind_param($stmtPesanan, "i", $id_user);
mysqli_stmt_execute($stmtPesanan);
$hasilPesanan = mysqli_stmt_get_result($stmtPesanan);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Profil Saya - LITERA</title>

<link rel="stylesheet" href="./style.css?v=10">

<style>
.profile-actions {
    display: flex;
    flex-direction: column;
    gap: 12px;
    margin-top: 25px;
}

.profile-button {
    display: block;
    text-align: center;
}

.btn-riwayat {
    display: block;
    text-align: center;
    padding: 13px 20px;
    background: #eee5f8;
    color: #71578b;
    border-radius: 10px;
    text-decoration: none;
    font-weight: 600;
    transition: .3s;
}

.btn-riwayat:hover {
    background: #d9c8eb;
}

.profile-actions .profile-logout {
    text-align: center;
}

.profile-orders {
    margin-top: 30px;
    text-align: left;
}

.profile-orders h2 {
    margin-bottom: 8px;
    color: #493c38;
}

.orders-description {
    color: #887b75;
    margin-bottom: 22px;
    font-size: 14px;
}

.order-item {
    padding: 20px;
    margin-bottom: 15px;
    border: 1px solid #eee5df;
    border-radius: 14px;
    background: #fffdf9;
}

.order-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
    margin-bottom: 15px;
}

.order-code {
    font-weight: 700;
    color: #59463f;
}

.order-status {
    padding: 7px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    background: #eee5f8;
    color: #71578b;
}

.order-info {
    display: grid;
    gap: 9px;
    margin-bottom: 17px;
}

.order-info p {
    display: flex;
    justify-content: space-between;
    gap: 15px;
    color: #756963;
    font-size: 14px;
}

.order-info strong {
    color: #493c38;
    text-align: right;
}

.order-total {
    border-top: 1px solid #eee5df;
    padding-top: 13px;
    display: flex;
    justify-content: space-between;
    gap: 10px;
    font-weight: 700;
    color: #493c38;
}

.btn-konfirmasi {
    display: block;
    width: 100%;
    margin-top: 16px;
    padding: 12px;
    border: none;
    border-radius: 10px;
    background: #8b719f;
    color: white;
    font-weight: 600;
    cursor: pointer;
    transition: .3s;
}

.btn-konfirmasi:hover {
    background: #725786;
}

.order-finished {
    margin-top: 14px;
    padding: 11px;
    border-radius: 9px;
    background: #eaf4e8;
    color: #52734e;
    text-align: center;
    font-size: 13px;
    font-weight: 600;
}

.empty-orders {
    padding: 25px;
    background: #fffdf9;
    border: 1px dashed #ded2c8;
    border-radius: 12px;
    text-align: center;
    color: #887b75;
}

.alert-profile {
    padding: 12px;
    margin-bottom: 18px;
    border-radius: 9px;
    background: #eaf4e8;
    color: #52734e;
    font-size: 14px;
}

.alert-error {
    background: #fbe9e7;
    color: #a34c43;
}
</style>
</head>

<body>

<header class="navbar">
    <a href="index.php" class="logo">LITERA<span>.</span></a>

    <nav>
        <a href="index.php">Beranda</a>
        <a href="katalog.php">Katalog</a>
        <a href="index.php#tentang">Tentang</a>
    </nav>

    <div class="nav-button">
        <a href="logout.php" class="btn-primary">Keluar</a>
    </div>
</header>

<main class="profile-page">

    <section class="profile-card">

        <div class="profile-avatar">
            <?php echo strtoupper(substr($user['nama'], 0, 1)); ?>
        </div>

        <p class="eyebrow">AKUN LITERA</p>

        <h1>
            Halo,
            <span><?php echo htmlspecialchars($user['nama']); ?>!</span>
        </h1>

        <p class="profile-description">
            Senang menemanimu dalam perjalanan membaca bersama LITERA.
        </p>

        <div class="profile-details">

            <div class="profile-detail">
                <span>Nama Lengkap</span>
                <strong><?php echo htmlspecialchars($user['nama']); ?></strong>
            </div>

            <div class="profile-detail">
                <span>Email</span>
                <strong><?php echo htmlspecialchars($user['email']); ?></strong>
            </div>

            <div class="profile-detail">
                <span>Bergabung Sejak</span>
                <strong>
                    <?php echo date('d F Y', strtotime($user['dibuat_pada'])); ?>
                </strong>
            </div>

        </div>

        <div class="profile-actions">
            <a href="katalog.php" class="btn-primary profile-button">
                Jelajahi Buku
            </a>

            <a href="riwayat_pesanan.php" class="btn-riwayat">
                Riwayat Pesanan
            </a>

            <a href="logout.php" class="profile-logout">
                Keluar dari Akun
            </a>
        </div>

    </section>

    <!-- PESANAN SAYA -->
    <section class="profile-card profile-orders">

        <h2>Pesanan Saya</h2>

        <p class="orders-description">
            Pantau pesananmu dan konfirmasi setelah buku diterima.
        </p>

        <?php if (isset($_GET['konfirmasi']) && $_GET['konfirmasi'] === 'berhasil'): ?>
            <div class="alert-profile">
                Pesanan berhasil dikonfirmasi. Status sekarang Selesai!
            </div>
        <?php endif; ?>

        <?php if ($pesan !== ""): ?>
            <div class="alert-profile alert-error">
                <?php echo htmlspecialchars($pesan); ?>
            </div>
        <?php endif; ?>

        <?php if (mysqli_num_rows($hasilPesanan) > 0): ?>

            <?php while ($pesanan = mysqli_fetch_assoc($hasilPesanan)): ?>

                <div class="order-item">

                    <div class="order-header">
                        <span class="order-code">
                            <?php echo htmlspecialchars($pesanan['kode_pesanan']); ?>
                        </span>

                        <span class="order-status">
                            <?php echo htmlspecialchars($pesanan['status']); ?>
                        </span>
                    </div>

                    <div class="order-info">

                        <p>
                            <span>Tanggal Pesanan</span>
                            <strong>
                                <?php echo date('d/m/Y', strtotime($pesanan['dibuat_pada'])); ?>
                            </strong>
                        </p>

                        <p>
                            <span>Metode Pembayaran</span>
                            <strong>
                                <?php echo htmlspecialchars($pesanan['metode_pembayaran']); ?>
                            </strong>
                        </p>

                    </div>

                    <div class="order-total">
                        <span>Total Pembayaran</span>
                        <strong>
                            Rp<?php echo number_format($pesanan['total'], 0, ',', '.'); ?>
                        </strong>
                    </div>

                    <?php if (trim($pesanan['status']) === 'Diantar'): ?>

                        <form method="POST" onsubmit="return confirm('Apakah barang sudah kamu terima?');">

                            <input
                                type="hidden"
                                name="id_pesanan"
                                value="<?php echo (int) $pesanan['id_pesanan']; ?>"
                            >

                            <button
                                type="submit"
                                name="konfirmasi_pesanan"
                                class="btn-konfirmasi"
                            >
                                Konfirmasi Pesanan Diterima
                            </button>

                        </form>

                    <?php elseif (trim($pesanan['status']) === 'Selesai'): ?>

                        <div class="order-finished">
                            ✓ Pesanan sudah selesai
                        </div>

                    <?php endif; ?>

                </div>

            <?php endwhile; ?>

        <?php else: ?>

            <div class="empty-orders">
                Kamu belum memiliki pesanan.
                <br>
                Yuk, temukan buku favoritmu di LITERA!
            </div>

        <?php endif; ?>

    </section>

</main>

<footer>
    <a href="index.php" class="logo">LITERA<span>.</span></a>
    <p>Temukan cerita, ciptakan kenangan.</p>
    <small>© 2026 LITERA. Semua hak dilindungi.</small>
</footer>

</body>
</html>
