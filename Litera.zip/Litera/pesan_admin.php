
<?php
require_once 'koneksi.php';

// Wajib login
if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit;
}

$id_user = $_SESSION['id_user'];
$pesan_sukses = "";
$pesan_error = "";

// Ambil data pengguna
$stmtUser = mysqli_prepare($conn, "
    SELECT nama, email FROM users WHERE id_user = ?
");
mysqli_stmt_bind_param($stmtUser, "i", $id_user);
mysqli_stmt_execute($stmtUser);
$user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmtUser));

// Kirim pesan
if (isset($_POST['kirim'])) {
    $subjek = trim($_POST['subjek']);
    $isi_pesan = trim($_POST['pesan']);

    if ($subjek === "" || $isi_pesan === "") {
        $pesan_error = "Semua kolom harus diisi.";
    } else {
        $stmt = mysqli_prepare($conn, "
            INSERT INTO pesan_admin (id_user, subjek, pesan)
            VALUES (?, ?, ?)
        ");

        mysqli_stmt_bind_param(
            $stmt,
            "iss",
            $id_user,
            $subjek,
            $isi_pesan
        );

        if (mysqli_stmt_execute($stmt)) {
            $pesan_sukses = "Pesan berhasil dikirim ke admin!";
        } else {
            $pesan_error = "Pesan gagal dikirim.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Admin - LITERA</title>
    <link rel="stylesheet" href="style.css?v=14">

    <style>
        .contact-admin {
            max-width: 650px;
            margin: 70px auto;
            padding: 35px;
            background: #fff;
            border-radius: 15px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.06);
        }

        .contact-admin h1 {
            margin-bottom: 10px;
        }

        .contact-admin p {
            margin-bottom: 20px;
        }

        .contact-admin input,
        .contact-admin textarea {
            width: 100%;
            padding: 13px;
            margin: 8px 0 18px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-family: inherit;
            font-size: 14px;
        }

        .contact-admin textarea {
            min-height: 150px;
            resize: vertical;
        }

        .contact-admin button {
            border: none;
            cursor: pointer;
            font-family: inherit;
        }

        .pesan-alert {
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 18px;
            background: #e9f5e9;
            color: #356b35;
        }

        .pesan-alert.error {
            background: #fbe9e9;
            color: #a33;
        }
    </style>
</head>

<body>

<header class="navbar">
    <a href="index.php" class="logo">LITERA<span>.</span></a>

    <nav>
        <a href="index.php">Beranda</a>
        <a href="katalog.php">Katalog</a>
        <a href="index.php#tentang">Tentang</a>
        <a href="index.php#kontak">Kontak</a>
    </nav>

    <div class="nav-button">
        <a href="profile.php" class="btn-outline">Profil</a>
        <a href="logout.php" class="btn-primary">Keluar</a>
    </div>
</header>

<main>

    <section class="contact-admin">

        <p class="eyebrow">LITERA BOOKSTORE</p>

        <h1>Contact to Admin</h1>

        <p>
            Punya pertanyaan, kendala, atau ingin menyampaikan sesuatu?
            Kirim pesan kepada admin melalui formulir berikut.
        </p>

        <?php if ($pesan_sukses): ?>
            <div class="pesan-alert">
                <?= htmlspecialchars($pesan_sukses); ?>
            </div>
        <?php endif; ?>

        <?php if ($pesan_error): ?>
            <div class="pesan-alert error">
                <?= htmlspecialchars($pesan_error); ?>
            </div>
        <?php endif; ?>

        <form method="POST">

            <label>Nama Pengguna</label>
            <input type="text"
                   value="<?= htmlspecialchars($user['nama'] ?? ''); ?>"
                   readonly>

            <label>Email</label>
            <input type="email"
                   value="<?= htmlspecialchars($user['email'] ?? ''); ?>"
                   readonly>

            <label>Subjek Pesan</label>
            <input type="text"
                   name="subjek"
                   placeholder="Masukkan subjek pesan"
                   required>

            <label>Isi Pesan</label>
            <textarea name="pesan"
                      placeholder="Tuliskan pesan kamu di sini..."
                      required></textarea>

            <button type="submit" name="kirim" class="btn-primary">
                Kirim Pesan
            </button>

        </form>

    </section>

</main>

<footer class="footer">
    <div class="footer-container">
        <h3>LITERA</h3>
        <p>Temukan bacaan favoritmu di sini.</p>
        <p>© 2026 LITERA BOOKSTORE. All Rights Reserved.</p>
    </div>
</footer>

</body>
</html>
