
<?php
require_once 'koneksi.php';

$pesan = "";

if (isset($_SESSION['id_user'])) {
    header("Location: index.php");
    exit;
}

if (isset($_POST['masuk'])) {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $pesan = "Email dan password harus diisi.";
    } else {
        $query = mysqli_prepare(
            $conn,
            "SELECT id_user, nama, email, password, role
             FROM users WHERE email = ?"
        );

        mysqli_stmt_bind_param($query, "s", $email);
        mysqli_stmt_execute($query);

        $hasil = mysqli_stmt_get_result($query);
        $user = mysqli_fetch_assoc($hasil);

        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true);

            $_SESSION['id_user'] = $user['id_user'];
            $_SESSION['nama'] = $user['nama'];
            $_SESSION['role'] = $user['role'];

            if ($user['role'] === 'admin') {
                header("Location: admin/dashboard.php");
            } else {
                header("Location: index.php");
            }

            exit;
        } else {
            $pesan = "Email atau password salah.";
        }

        mysqli_stmt_close($query);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk - LITERA</title>
    <link rel="stylesheet" href="style.css?v=11">

    <style>
        .password-field {
            position: relative;
        }

        .password-field input {
            width: 100%;
            padding-right: 45px !important;
        }

        .toggle-password {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            border: none;
            background: none;
            cursor: pointer;
            color: #80639e;
            padding: 5px;
        }

        .toggle-password svg {
            width: 20px;
            height: 20px;
            fill: none;
            stroke: currentColor;
            stroke-width: 1.8;
            stroke-linecap: round;
            stroke-linejoin: round;
        }

        .eye-off {
            display: none;
        }

        .password-visible .eye {
            display: none;
        }

        .password-visible .eye-off {
            display: block;
        }
    </style>
</head>
<body>

<header class="navbar">
    <a href="index.php" class="logo">LITERA<span>.</span></a>

    <nav>
        <a href="index.php">Beranda</a>
        <a href="katalog.php">Katalog</a>
        <a href="index.php#tentang">Tentang</a>
    </nav>

    <div class="nav-button">
        <a href="register.php" class="btn-outline">Daftar</a>
    </div>
</header>

<main class="auth-page">
    <div class="auth-card">

        <div class="auth-heading">
            <p class="eyebrow">SELAMAT DATANG KEMBALI</p>
            <h1>Masuk ke <span>LITERA.</span></h1>
            <p>Masuk untuk melanjutkan belanja bukumu.</p>
        </div>

        <?php if (!empty($pesan)): ?>
            <div class="auth-message error">
                <?php echo htmlspecialchars($pesan); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">

            <div class="form-group">
                <label>Email</label>
                <input
                    type="email"
                    name="email"
                    placeholder="Masukkan email"
                    value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label>Password</label>

                <div class="password-field">
                    <input
                        type="password"
                        name="password"
                        id="password-login"
                        placeholder="Masukkan password"
                        required
                    >

                    <button
                        type="button"
                        class="toggle-password"
                        onclick="togglePassword('password-login', this)"
                    >
                        <svg class="eye" viewBox="0 0 24 24">
                            <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/>
                            <circle cx="12" cy="12" r="3"/>
                        </svg>

                        <svg class="eye-off" viewBox="0 0 24 24">
                            <path d="m3 3 18 18"/>
                            <path d="M2 12s3.5-7 10-7c6.5 0 10 7 10 7s-3.5 7-10 7S2 12 2 12Z"/>
                        </svg>
                    </button>
                </div>
            </div>

            <button type="submit" name="masuk" class="auth-button">
                Masuk Sekarang
            </button>

        </form>

        <p class="auth-switch">
            Belum punya akun?
            <a href="register.php">Daftar di sini</a>
        </p>

    </div>
</main>

<footer>
    <a href="index.php" class="logo">LITERA<span>.</span></a>
    <p>Temukan cerita, ciptakan kenangan.</p>
    <small>© 2026 LITERA. Semua hak dilindungi.</small>
</footer>

<script>
function togglePassword(id, tombol) {
    const input = document.getElementById(id);

    if (input.type === "password") {
        input.type = "text";
        tombol.classList.add("password-visible");
    } else {
        input.type = "password";
        tombol.classList.remove("password-visible");
    }
}
</script>

</body>
</html>
