
<?php
require_once 'koneksi.php';

if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit;
}

$idUser = (int) $_SESSION['id_user'];

$pesan = "";
$jenisPesan = "";

// PROSES KONFIRMASI PESANAN OLEH USER
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['konfirmasi_pesanan'])) {

    $idPesanan = isset($_POST['id_pesanan'])
        ? (int) $_POST['id_pesanan']
        : 0;

    if ($idPesanan > 0) {

        $stmtKonfirmasi = mysqli_prepare($conn, "
            UPDATE pesanan
            SET status = 'Selesai'
            WHERE id_pesanan = ?
            AND id_user = ?
            AND status = 'Diantar'
        ");

        mysqli_stmt_bind_param(
            $stmtKonfirmasi,
            "ii",
            $idPesanan,
            $idUser
        );

        if (mysqli_stmt_execute($stmtKonfirmasi)) {

            if (mysqli_stmt_affected_rows($stmtKonfirmasi) === 1) {
                header("Location: riwayat_pesanan.php?konfirmasi=berhasil");
                exit;
            } else {
                $pesan = "Pesanan tidak dapat dikonfirmasi. Pastikan pesanan milikmu dan statusnya Diantar.";
                $jenisPesan = "error";
            }

        } else {
            $pesan = "Gagal mengubah status pesanan.";
            $jenisPesan = "error";
        }

        mysqli_stmt_close($stmtKonfirmasi);

    } else {
        $pesan = "ID pesanan tidak valid.";
        $jenisPesan = "error";
    }
}

// NOTIFIKASI
if (isset($_GET['konfirmasi']) && $_GET['konfirmasi'] === 'berhasil') {
    $pesan = "Pesanan berhasil dikonfirmasi. Terima kasih sudah berbelanja di LITERA!";
    $jenisPesan = "success";
}

// AMBIL PESANAN MILIK USER YANG LOGIN
$stmt = mysqli_prepare($conn, "
    SELECT *
    FROM pesanan
    WHERE id_user = ?
    ORDER BY dibuat_pada DESC
");

mysqli_stmt_bind_param($stmt, "i", $idUser);
mysqli_stmt_execute($stmt);

$pesanan = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Pesanan - LITERA</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 35px 7%;
            background: #faf6ff;
            font-family: Arial, sans-serif;
            color: #493b59;
        }

        .container {
            max-width: 1000px;
            margin: auto;
        }

        .header {
            margin-bottom: 30px;
        }

        .header a {
            color: #9176ad;
            text-decoration: none;
            font-size: 14px;
        }

        .header h1 {
            margin: 20px 0 8px;
            font-size: 30px;
        }

        .header p {
            color: #81718f;
            font-size: 14px;
        }

        .pesan {
            padding: 13px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .success {
            background: #e5f5e9;
            color: #26733b;
        }

        .error {
            background: #fde8e8;
            color: #a83232;
        }

        .order-card {
            background: white;
            border: 1px solid #e8def2;
            border-radius: 13px;
            padding: 23px;
            margin-bottom: 18px;
            box-shadow: 0 4px 15px rgba(73, 59, 89, .04);
        }

        .order-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
            padding-bottom: 17px;
            border-bottom: 1px solid #eee5f8;
        }

        .order-code {
            font-weight: bold;
            font-size: 15px;
        }

        .order-date {
            color: #81718f;
            font-size: 12px;
            margin-top: 6px;
        }

        .status {
            display: inline-block;
            padding: 8px 13px;
            border-radius: 20px;
            background: #eee5f8;
            color: #71578b;
            font-size: 12px;
            font-weight: bold;
        }

        .order-info {
            display: flex;
            justify-content: space-between;
            gap: 15px;
            flex-wrap: wrap;
            padding: 20px 0;
        }

        .info-label {
            color: #9685a5;
            font-size: 12px;
            margin-bottom: 7px;
        }

        .info-value {
            font-size: 14px;
            font-weight: bold;
        }

        .order-bottom {
            border-top: 1px solid #eee5f8;
            padding-top: 17px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        .total-label {
            color: #81718f;
            font-size: 12px;
            margin-bottom: 5px;
        }

        .total-price {
            font-size: 19px;
            font-weight: bold;
            color: #80639e;
        }

        .action-buttons {
            display: flex;
            align-items: center;
            gap: 9px;
            flex-wrap: wrap;
        }

        .detail-button {
            display: inline-block;
            padding: 11px 18px;
            background: #b69bd3;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 13px;
            font-weight: bold;
        }

        .detail-button:hover {
            background: #9e80c0;
        }

        .confirm-button {
            padding: 11px 16px;
            background: #6e9b79;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 13px;
            font-weight: bold;
            cursor: pointer;
        }

        .confirm-button:hover {
            background: #568362;
        }

        .finished {
            color: #568362;
            font-size: 13px;
            font-weight: bold;
        }

        .empty {
            background: white;
            border: 1px solid #e8def2;
            border-radius: 13px;
            padding: 55px 20px;
            text-align: center;
        }

        .empty h3 {
            margin-bottom: 10px;
        }

        .empty p {
            color: #81718f;
            font-size: 14px;
            margin-bottom: 22px;
        }

        .shop-button {
            display: inline-block;
            padding: 12px 20px;
            background: #b69bd3;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 13px;
        }

        @media(max-width: 600px) {
            body {
                padding: 25px 5%;
            }

            .header h1 {
                font-size: 25px;
            }

            .order-card {
                padding: 17px;
            }

            .action-buttons {
                width: 100%;
            }
        }
    </style>
</head>

<body>

<div class="container">

    <div class="header">
        <a href="profile.php">← Kembali ke Profil</a>
        <h1>Riwayat Pesanan</h1>
        <p>Lihat semua pesanan yang pernah kamu buat di LITERA.</p>
    </div>

    <?php if ($pesan !== ""): ?>
        <div class="pesan <?= htmlspecialchars($jenisPesan); ?>">
            <?= htmlspecialchars($pesan); ?>
        </div>
    <?php endif; ?>

    <?php if (mysqli_num_rows($pesanan) > 0): ?>

        <?php while ($row = mysqli_fetch_assoc($pesanan)): ?>

            <div class="order-card">

                <div class="order-top">

                    <div>
                        <div class="order-code">
                            <?= htmlspecialchars($row['kode_pesanan']); ?>
                        </div>

                        <div class="order-date">
                            <?= date('d M Y, H:i', strtotime($row['dibuat_pada'])); ?>
                        </div>
                    </div>

                    <span class="status">
                        <?= htmlspecialchars($row['status']); ?>
                    </span>

                </div>

                <div class="order-info">

                    <div>
                        <div class="info-label">Metode Pembayaran</div>
                        <div class="info-value">
                            <?= htmlspecialchars($row['metode_pembayaran']); ?>
                        </div>
                    </div>

                    <div>
                        <div class="info-label">Kode Pesanan</div>
                        <div class="info-value">
                            <?= htmlspecialchars($row['kode_pesanan']); ?>
                        </div>
                    </div>

                </div>

                <div class="order-bottom">

                    <div>
                        <div class="total-label">Total Pembayaran</div>

                        <div class="total-price">
                            Rp<?= number_format($row['total'], 0, ',', '.'); ?>
                        </div>
                    </div>

                    <div class="action-buttons">

                        <a
                            href="struk.php?id=<?= (int) $row['id_pesanan']; ?>"
                            class="detail-button"
                        >
                            Lihat Struk
                        </a>

                        <?php if ($row['status'] === 'Diantar'): ?>

                            <form method="POST"
                                  onsubmit="return confirm('Apakah barang sudah kamu terima?');">

                                <input
                                    type="hidden"
                                    name="id_pesanan"
                                    value="<?= (int) $row['id_pesanan']; ?>"
                                >

                                <button
                                    type="submit"
                                    name="konfirmasi_pesanan"
                                    class="confirm-button"
                                >
                                    Konfirmasi Pesanan Diterima
                                </button>

                            </form>

                        <?php elseif ($row['status'] === 'Selesai'): ?>

                            <span class="finished">
                                ✓ Pesanan Selesai
                            </span>

                        <?php endif; ?>

                    </div>

                </div>

            </div>

        <?php endwhile; ?>

    <?php else: ?>

        <div class="empty">
            <h3>Belum Ada Pesanan</h3>
            <p>Pesanan yang kamu buat nantinya akan muncul di sini.</p>

            <a href="katalog.php" class="shop-button">
                Mulai Belanja
            </a>
        </div>

    <?php endif; ?>

</div>

</body>
</html>
