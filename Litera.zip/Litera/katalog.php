
<?php
require_once 'koneksi.php';

// Pencarian buku
$keyword = trim($_GET['cari'] ?? '');

if ($keyword !== '') {
    $cari = "%" . $keyword . "%";

    $stmt = mysqli_prepare($conn, "
        SELECT * FROM buku
        WHERE judul LIKE ? OR penulis LIKE ?
        ORDER BY dibuat_pada DESC
    ");

    mysqli_stmt_bind_param($stmt, "ss", $cari, $cari);
    mysqli_stmt_execute($stmt);
    $query = mysqli_stmt_get_result($stmt);
} else {
    $query = mysqli_query($conn, "
        SELECT * FROM buku
        ORDER BY dibuat_pada DESC
    ");
}

if (!$query) {
    die("Gagal mengambil data buku: " . mysqli_error($conn));
}

// Fungsi gambar buku
function gambarBuku($nama) {
    if (empty($nama)) {
        return '';
    }

    $nama = basename(str_replace('\\', '/', $nama));

    $lokasi = __DIR__ . '/uploads/' . $nama;

    if (file_exists($lokasi)) {
        return 'uploads/' . rawurlencode($nama);
    }

    return '';
}

// Hitung jumlah buku di keranjang
$jumlahKeranjang = 0;

if (isset($_SESSION['keranjang'])) {
    foreach ($_SESSION['keranjang'] as $jumlah) {
        $jumlahKeranjang += (int) $jumlah;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Katalog Buku - LITERA</title>

    <link rel="stylesheet" href="./style.css?v=11">

    <style>
        .catalog-search {
            max-width: 600px;
            margin: 30px auto 0;
            display: flex;
            gap: 10px;
        }

        .catalog-search input {
            flex: 1;
            min-width: 0;
            padding: 14px 18px;
            border: 1px solid #d9c8eb;
            border-radius: 10px;
            outline: none;
            background: white;
            color: #493b59;
            font-size: 14px;
        }

        .catalog-search input:focus {
            border-color: #b69bd3;
        }

        .catalog-search button {
            padding: 13px 22px;
            border: none;
            border-radius: 10px;
            background: #b69bd3;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }

        .catalog-search button:hover {
            background: #9e80c0;
        }

        .cart-nav {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 10px 13px;
            border-radius: 9px;
            background: #eee5f8;
            color: #71578b;
            text-decoration: none;
            font-weight: bold;
            font-size: 14px;
        }

        .cart-nav:hover {
            background: #d9c8eb;
        }

        .cart-count {
            background: #b69bd3;
            color: white;
            border-radius: 50%;
            min-width: 20px;
            height: 20px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
        }

        .book-item {
            overflow: hidden;
        }

        .book-image a {
            display: block;
        }

        .book-image img {
            cursor: pointer;
        }

        .book-title-link {
            color: inherit;
            text-decoration: none;
        }

        .book-title-link:hover {
            color: #9e80c0;
        }

        .book-actions {
            margin-top: 16px;
        }

        .book-detail-button,
        .add-cart-button {
            display: block;
            width: 100%;
            text-align: center;
            padding: 11px 10px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 13px;
            font-weight: bold;
            cursor: pointer;
        }

        .book-detail-button {
            background: #eee5f8;
            color: #71578b;
            margin-bottom: 8px;
        }

        .add-cart-button {
            border: none;
            background: #b69bd3;
            color: white;
        }

        .book-detail-button:hover {
            background: #d9c8eb;
        }

        .add-cart-button:hover {
            background: #9e80c0;
        }

        .add-cart-button:disabled {
            background: #d8d2df;
            cursor: not-allowed;
        }

        .no-image {
            width: 100%;
            min-height: 250px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            background: #eee5f8;
            color: #81718f;
        }

        .no-image span {
            font-size: 24px;
            font-weight: bold;
        }

        .catalog-empty {
            text-align: center;
            padding: 55px 20px;
            color: #81718f;
            grid-column: 1 / -1;
        }

        .catalog-empty h3 {
            color: #493b59;
            margin-bottom: 10px;
        }

        .nav-button {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        /* Kontak */
        .contact-section {
            padding: 55px 20px;
            background: #f5edf9;
            text-align: center;
            margin-top: 50px;
        }

        .contact-section h2 {
            color: #493b59;
            margin-bottom: 12px;
        }

        .contact-section p {
            color: #81718f;
            margin-bottom: 20px;
        }

        .contact-links {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 15px;
        }

        .contact-links a {
            color: #71578b;
            text-decoration: none;
            background: white;
            padding: 12px 20px;
            border-radius: 8px;
        }

        .contact-links a:hover {
            background: #eee5f8;
        }

        @media(max-width: 600px) {
            .catalog-search {
                flex-wrap: wrap;
            }

            .catalog-search button {
                flex: 1;
            }

            .nav-button {
                gap: 6px;
            }
        }
    </style>
</head>

<body>

<header class="navbar">

    <a href="index.php" class="logo">LITERA<span>.</span></a>

    <nav>
        <a href="index.php">Beranda</a>
        <a href="katalog.php">Katalog</a>
        <a href="index.php#tentang">Tentang</a>
        <a href="#kontak">Kontak</a>
    </nav>

    <div class="nav-button">

        <a href="keranjang.php" class="cart-nav">
            🛒 Keranjang
            <span class="cart-count">
                <?= $jumlahKeranjang; ?>
            </span>
        </a>

        <?php if (isset($_SESSION['id_user'])): ?>

            <a href="profile.php" class="btn-outline">Profil</a>
            <a href="logout.php" class="btn-primary">Keluar</a>

        <?php else: ?>

            <a href="login.php" class="btn-outline">Masuk</a>
            <a href="register.php" class="btn-primary">Daftar</a>

        <?php endif; ?>

    </div>

</header>

<main class="catalog-page">

    <section class="catalog-heading">

        <p class="eyebrow">JELAJAHI KOLEKSI KAMI</p>

        <h1>Temukan Buku <span>Favoritmu.</span></h1>

        <p>
            Setiap halaman menyimpan cerita.
            Temukan bacaan yang ingin kamu bawa pulang.
        </p>

        <form action="katalog.php" method="GET" class="catalog-search">

            <input
                type="text"
                name="cari"
                placeholder="Cari judul buku atau nama penulis..."
                value="<?= htmlspecialchars($keyword); ?>"
            >

            <button type="submit">Cari Buku</button>

        </form>

    </section>

    <section class="catalog-content">

        <?php if (mysqli_num_rows($query) > 0): ?>

            <div class="book-grid">

                <?php while ($buku = mysqli_fetch_assoc($query)): ?>

                    <?php
                    $gambar = gambarBuku($buku['gambar']);
                    ?>

                    <div class="book-item">

                        <div class="book-image">

                            <a href="detail_buku.php?id=<?= (int) $buku['id_buku']; ?>">

                                <?php if ($gambar !== ''): ?>

                                    <img
                                        src="<?= htmlspecialchars($gambar); ?>"
                                        alt="<?= htmlspecialchars($buku['judul']); ?>"
                                    >

                                <?php else: ?>

                                    <div class="no-image">
                                        <span>LITERA</span>
                                        <small>Book Collection</small>
                                    </div>

                                <?php endif; ?>

                            </a>

                        </div>

                        <div class="book-info">

                            <p class="book-category">
                                <?= htmlspecialchars($buku['kategori']); ?>
                            </p>

                            <h3>
                                <a
                                    class="book-title-link"
                                    href="detail_buku.php?id=<?= (int) $buku['id_buku']; ?>"
                                >
                                    <?= htmlspecialchars($buku['judul']); ?>
                                </a>
                            </h3>

                            <p class="book-author">
                                <?= htmlspecialchars($buku['penulis']); ?>
                            </p>

                            <p class="book-price">
                                Rp <?= number_format($buku['harga'], 0, ',', '.'); ?>
                            </p>

                            <p class="book-stock">
                                Stok: <?= (int) $buku['stok']; ?>
                            </p>

                            <div class="book-actions">

                                <a
                                    href="detail_buku.php?id=<?= (int) $buku['id_buku']; ?>"
                                    class="book-detail-button"
                                >
                                    Lihat Detail
                                </a>

                                <form action="keranjang.php" method="POST">

                                    <input
                                        type="hidden"
                                        name="id_buku"
                                        value="<?= (int) $buku['id_buku']; ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="jumlah"
                                        value="1"
                                    >

                                    <button
                                        type="submit"
                                        name="tambah_keranjang"
                                        class="add-cart-button"
                                        <?= (int) $buku['stok'] <= 0 ? 'disabled' : ''; ?>
                                    >
                                        <?= (int) $buku['stok'] <= 0
                                            ? 'Stok Habis'
                                            : '+ Tambah ke Keranjang'; ?>
                                    </button>

                                </form>

                            </div>

                        </div>

                    </div>

                <?php endwhile; ?>

            </div>

        <?php else: ?>

            <div class="catalog-empty">

                <h3>Buku Tidak Ditemukan</h3>

                <p>
                    Maaf, buku dengan kata kunci
                    "<?= htmlspecialchars($keyword); ?>"
                    belum ditemukan.
                </p>

                <a href="katalog.php" class="book-detail-button">
                    Lihat Semua Buku
                </a>

            </div>

        <?php endif; ?>

    </section>

</main>

<section class="contact-section" id="kontak">

    <h2>Hubungi Kami</h2>

    <p>
        Punya pertanyaan atau ingin mengetahui lebih lanjut tentang LITERA?
        Hubungi kami melalui kontak berikut.
    </p>

    <div class="contact-links">

        <a href="mailto:LITERA@gmail.com">
            ✉ LITERA@gmail.com
        </a>

        <a href="https://wa.me/6285756180799" target="_blank">
            WhatsApp
        </a>

    </div>

</section>

<footer>

    <a href="index.php" class="logo">LITERA<span>.</span></a>

    <p>Temukan cerita, ciptakan kenangan.</p>

    <small>© 2026 LITERA. Semua hak dilindungi.</small>

</footer>

</body>
</html>
