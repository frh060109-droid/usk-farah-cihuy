
<?php
require_once 'koneksi.php';

if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit;
}

if (empty($_SESSION['keranjang'])) {
    header("Location: keranjang.php");
    exit;
}

$items = [];
$total = 0;
$ongkir = 10000;
$stokTidakCukup = false;

foreach ($_SESSION['keranjang'] as $id => $jumlah) {
    $id = (int) $id;
    $jumlah = (int) $jumlah;

    if ($id <= 0 || $jumlah <= 0) {
        continue;
    }

    $stmt = mysqli_prepare($conn, "
        SELECT * FROM buku WHERE id_buku = ?
    ");

    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);

    $hasil = mysqli_stmt_get_result($stmt);
    $buku = mysqli_fetch_assoc($hasil);

    if ($buku) {
        $buku['jumlah_beli'] = $jumlah;
        $buku['subtotal'] = $buku['harga'] * $jumlah;

        if ($jumlah > $buku['stok']) {
            $stokTidakCukup = true;
        }

        $items[] = $buku;
        $total += $buku['subtotal'];
    }
}

if (empty($items)) {
    header("Location: keranjang.php");
    exit;
}

$totalPembayaran = $total + $ongkir;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - LITERA</title>

    <link rel="stylesheet" href="style.css?v=10">

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            background: #faf6ff;
            color: #493b59;
        }

        .checkout-page {
            max-width: 1100px;
            margin: 55px auto;
            padding: 0 20px;
        }

        .checkout-heading {
            margin-bottom: 30px;
        }

        .checkout-heading h1 {
            font-size: 32px;
            margin-bottom: 8px;
        }

        .checkout-heading p {
            color: #81718f;
            font-size: 14px;
        }

        .checkout-layout {
            display: grid;
            grid-template-columns: 1.3fr .9fr;
            gap: 25px;
            align-items: start;
        }

        .checkout-card {
            background: #fff;
            border: 1px solid #e8def2;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
        }

        .checkout-card h2 {
            font-size: 19px;
            margin: 0 0 22px;
        }

        .form-group {
            margin-bottom: 17px;
        }

        .form-group label {
            display: block;
            font-size: 13px;
            font-weight: bold;
            margin-bottom: 8px;
        }

        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 13px;
            border: 1px solid #e1d5ed;
            border-radius: 9px;
            outline: none;
            font-family: inherit;
            font-size: 14px;
            color: #493b59;
            background: #fff;
        }

        .form-group input:focus,
        .form-group textarea:focus {
            border-color: #b69bd3;
        }

        .form-group textarea {
            resize: vertical;
            min-height: 90px;
        }

        .payment-option {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 15px;
            border: 1px solid #e8def2;
            border-radius: 10px;
            margin-bottom: 12px;
            cursor: pointer;
        }

        .payment-option input {
            accent-color: #a88ac7;
            margin-top: 3px;
        }

        .payment-option strong {
            font-size: 14px;
        }

        .payment-option small {
            display: block;
            color: #81718f;
            margin-top: 5px;
            font-size: 12px;
        }

        .bank-info {
            background: #f7f1fc;
            border: 1px solid #e5d9f1;
            border-radius: 10px;
            padding: 17px;
            margin: 15px 0;
        }

        .bank-info h3 {
            font-size: 15px;
            margin: 0 0 13px;
        }

        .bank-info p {
            font-size: 13px;
            margin: 8px 0;
        }

        .bank-info strong {
            color: #80639e;
        }

        .simulation-note {
            font-size: 12px;
            color: #81718f;
            line-height: 1.6;
            margin-top: 12px;
        }

        .upload-box {
            margin-top: 18px;
            padding: 16px;
            background: #fcfaff;
            border: 1px dashed #b69bd3;
            border-radius: 10px;
        }

        .upload-box label {
            display: block;
            font-weight: bold;
            font-size: 13px;
            margin-bottom: 10px;
        }

        .upload-box input {
            width: 100%;
            font-size: 12px;
        }

        .upload-box small {
            display: block;
            color: #81718f;
            margin-top: 10px;
            line-height: 1.5;
        }

        .order-item {
            display: flex;
            align-items: center;
            gap: 13px;
            padding: 13px 0;
            border-bottom: 1px solid #eee5f8;
        }

        .order-image {
            width: 65px;
            height: 85px;
            border-radius: 7px;
            object-fit: contain;
            background: #eee5f8;
        }

        .order-image-placeholder {
            width: 65px;
            height: 85px;
            background: #eee5f8;
            border-radius: 7px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .order-book {
            flex: 1;
            min-width: 0;
        }

        .order-book strong {
            font-size: 14px;
            display: block;
        }

        .order-book small {
            color: #81718f;
            display: block;
            margin-top: 7px;
            font-size: 12px;
        }

        .order-price {
            font-size: 13px;
            font-weight: bold;
            white-space: nowrap;
        }

        .price-detail {
            margin-top: 20px;
            padding-top: 15px;
            border-top: 1px solid #e8def2;
        }

        .price-row {
            display: flex;
            justify-content: space-between;
            gap: 10px;
            margin-bottom: 13px;
            font-size: 14px;
        }

        .price-row span:first-child {
            color: #81718f;
        }

        .price-row strong {
            color: #493b59;
        }

        .order-total {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            border-top: 1px solid #e8def2;
            margin-top: 15px;
            padding-top: 18px;
            font-weight: bold;
        }

        .order-total strong {
            font-size: 21px;
            color: #80639e;
        }

        .checkout-submit {
            width: 100%;
            padding: 15px;
            margin-top: 20px;
            background: #b69bd3;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 14px;
            font-weight: bold;
            cursor: pointer;
        }

        .checkout-submit:hover {
            background: #9e80c0;
        }

        .checkout-submit:disabled {
            background: #c9c0d2;
            cursor: not-allowed;
        }

        .stock-warning {
            padding: 13px;
            background: #fff1f1;
            color: #a34444;
            border-radius: 9px;
            margin-bottom: 18px;
            font-size: 13px;
        }

        .back-link {
            display: inline-block;
            color: #80639e;
            text-decoration: none;
            font-size: 13px;
            margin-bottom: 20px;
        }

        @media(max-width: 750px) {
            .checkout-layout {
                grid-template-columns: 1fr;
            }

            .checkout-heading h1 {
                font-size: 26px;
            }
        }
    </style>
</head>

<body>

<header class="navbar">
    <a href="index.php" class="logo">LITERA<span>.</span></a>

    <nav>
        <a href="index.php">Beranda</a>
        <a href="katalog.php">Katalog</a>
        <a href="index.php#tentang">Tentang</a>
    </nav>

    <div class="nav-button">
        <a href="profile.php" class="btn-outline">Profil</a>
        <a href="logout.php" class="btn-primary">Keluar</a>
    </div>
</header>

<main class="checkout-page">

    <a href="keranjang.php" class="back-link">
        ← Kembali ke Keranjang
    </a>

    <div class="checkout-heading">
        <h1>Checkout Pesanan</h1>
        <p>Lengkapi informasi pengiriman dan pembayaranmu.</p>
    </div>

    <?php if (isset($_SESSION['error_checkout'])): ?>
        <div class="stock-warning">
            <?= htmlspecialchars($_SESSION['error_checkout']); ?>
        </div>
        <?php unset($_SESSION['error_checkout']); ?>
    <?php endif; ?>

    <?php if ($stokTidakCukup): ?>
        <div class="stock-warning">
            Ada buku yang stoknya tidak mencukupi. Silakan kembali ke keranjang dan sesuaikan jumlah pembelian.
        </div>
    <?php endif; ?>

    <form action="proses_checkout.php" method="POST" enctype="multipart/form-data">

        <div class="checkout-layout">

            <div>

                <section class="checkout-card">

                    <h2>Informasi Pengiriman</h2>

                    <div class="form-group">
                        <label>Nama Penerima</label>
                        <input
                            type="text"
                            name="nama_penerima"
                            placeholder="Masukkan nama penerima"
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label>Nomor Telepon</label>
                        <input
                            type="tel"
                            name="telepon"
                            placeholder="Masukkan nomor telepon"
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label>Alamat Lengkap</label>
                        <textarea
                            name="alamat"
                            placeholder="Masukkan alamat lengkap pengiriman"
                            required
                        ></textarea>
                    </div>

                    <div class="form-group">
                        <label>Catatan (Opsional)</label>
                        <textarea
                            name="catatan"
                            placeholder="Catatan tambahan untuk pesanan..."
                        ></textarea>
                    </div>

                </section>

                <section class="checkout-card">

                    <h2>Metode Pembayaran</h2>

                    <label class="payment-option">
                        <input
                            type="radio"
                            name="metode_pembayaran"
                            value="Transfer Bank"
                            checked
                            required
                        >

                        <span>
                            <strong>Transfer Bank</strong>
                            <small>Transfer melalui rekening simulasi LITERA.</small>
                        </span>
                    </label>

                    <div class="bank-info">

                        <h3>Informasi Rekening Pembayaran</h3>

                        <p>Bank: <strong>BCA (Simulasi)</strong></p>
                        <p>Nomor Rekening: <strong>7281945630</strong></p>
                        <p>Atas Nama: <strong>LITERA BOOKSTORE</strong></p>

                        <p class="simulation-note">
                            *Rekening ini hanya untuk simulasi proyek sekolah dan bukan rekening bank sungguhan.
                        </p>

                    </div>

                    <div class="upload-box">

                        <label for="bukti_pembayaran">
                            Upload Bukti Pembayaran Transfer
                        </label>

                        <input
                            type="file"
                            name="bukti_pembayaran"
                            id="bukti_pembayaran"
                            accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                            required
                        >

                        <small>
                            Format JPG, PNG, atau WEBP, maksimal 2 MB.
                            Wajib diisi sebelum membuat pesanan.
                        </small>

                    </div>

                </section>

            </div>

            <div>

                <section class="checkout-card">

                    <h2>Ringkasan Pesanan</h2>

                    <?php foreach ($items as $buku): ?>

                        <div class="order-item">

                            <?php
                            $gambarFile = !empty($buku['gambar'])
                                ? basename(str_replace('\\', '/', $buku['gambar']))
                                : '';

                            $gambarPath = __DIR__ . '/uploads/' . $gambarFile;
                            $gambarUrl = 'uploads/' . rawurlencode($gambarFile);
                            ?>

                            <?php if ($gambarFile && is_file($gambarPath)): ?>
                                <img
                                    class="order-image"
                                    src="<?= htmlspecialchars($gambarUrl); ?>"
                                    alt="<?= htmlspecialchars($buku['judul']); ?>"
                                >
                            <?php else: ?>
                                <div class="order-image-placeholder">📚</div>
                            <?php endif; ?>

                            <div class="order-book">
                                <strong>
                                    <?= htmlspecialchars($buku['judul']); ?>
                                </strong>

                                <small>
                                    <?= $buku['jumlah_beli']; ?> buku
                                </small>
                            </div>

                            <div class="order-price">
                                Rp<?= number_format($buku['subtotal'], 0, ',', '.'); ?>
                            </div>

                        </div>

                    <?php endforeach; ?>

                    <div class="price-detail">

                        <div class="price-row">
                            <span>Subtotal Buku</span>
                            <strong>
                                Rp<?= number_format($total, 0, ',', '.'); ?>
                            </strong>
                        </div>

                        <div class="price-row">
                            <span>Ongkir</span>
                            <strong>
                                Rp<?= number_format($ongkir, 0, ',', '.'); ?>
                            </strong>
                        </div>

                    </div>

                    <div class="order-total">
                        <span>Total Pembayaran</span>

                        <strong>
                            Rp<?= number_format($totalPembayaran, 0, ',', '.'); ?>
                        </strong>
                    </div>

                    <button
                        type="submit"
                        class="checkout-submit"
                        <?= $stokTidakCukup ? 'disabled' : ''; ?>
                    >
                        Buat Pesanan
                    </button>

                </section>

            </div>

        </div>

    </form>

</main>

</body>
</html>
