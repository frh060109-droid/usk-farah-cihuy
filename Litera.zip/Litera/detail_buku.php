<?php
require_once 'koneksi.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: katalog.php");
    exit;
}

$id_buku = (int) $_GET['id'];

$query = mysqli_query($conn, "SELECT * FROM buku WHERE id_buku = $id_buku");

if (!$query || mysqli_num_rows($query) == 0) {
    header("Location: katalog.php");
    exit;
}

$buku = mysqli_fetch_assoc($query);

$namaGambar = trim($buku['gambar'] ?? '');
$namaGambar = basename(str_replace('\\', '/', $namaGambar));

$pathGambar = __DIR__ . '/uploads/' . $namaGambar;
$gambar = '';

if ($namaGambar !== '' && is_file($pathGambar)) {
    $gambar = 'uploads/' . rawurlencode($namaGambar);
}

$jumlahKeranjang = 0;

if (!empty($_SESSION['keranjang'])) {
    foreach ($_SESSION['keranjang'] as $jumlah) {
        $jumlahKeranjang += (int) $jumlah;
    }
}

$stok = (int) $buku['stok'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($buku['judul']); ?> - LITERA</title>
    <link rel="stylesheet" href="style.css?v=112">

    <style>
        .book-detail-page {
            min-height: 650px;
            padding: 65px 10%;
            background: var(--cream);
        }

        .book-detail-container {
            max-width: 1000px;
            margin: auto;
            display: flex;
            align-items: flex-start;
            gap: 55px;
            padding: 38px;
            background: var(--white);
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(85, 70, 95, 0.06);
        }

        .book-detail-image {
            width: 320px;
            flex-shrink: 0;
            min-height: 380px;
            background: var(--lilac-light);
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            border-radius: 8px;
        }

        .book-detail-image img {
            display: block;
            width: 100%;
            max-height: 440px;
            object-fit: contain;
        }

        .no-cover {
            color: var(--muted);
            font-size: 14px;
            text-align: center;
            padding: 20px;
        }

        .book-detail-info {
            flex: 1;
        }

        .book-detail-info .category {
            display: inline-block;
            padding: 7px 15px;
            margin-bottom: 17px;
            border-radius: 6px;
            background: var(--lilac-light);
            color: var(--purple-dark);
            font-size: 12px;
            font-weight: 600;
        }

        .book-detail-info h1 {
            font-family: 'Playfair Display', serif;
            font-size: 32px;
            line-height: 1.3;
            color: var(--text);
            margin-bottom: 10px;
        }

        .book-detail-info .author {
            color: var(--muted);
            font-size: 14px;
            margin-bottom: 22px;
        }

        .book-detail-info .price {
            color: var(--purple-dark);
            font-size: 25px;
            font-weight: 700;
            margin-bottom: 22px;
        }

        .book-detail-info .description {
            color: var(--muted);
            font-size: 14px;
            line-height: 1.9;
            margin-bottom: 22px;
        }

        .book-detail-info .book-stock {
            color: var(--text);
            font-size: 13px;
            margin-bottom: 22px;
        }

        .quantity-group {
            margin-bottom: 22px;
        }

        .quantity-group label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 9px;
        }

        .quantity-group input {
            width: 90px;
            padding: 12px;
            border: 1px solid #E5DCEC;
            border-radius: 6px;
            background: var(--white);
            color: var(--text);
            font-family: inherit;
            outline: none;
        }

        .quantity-group input:focus {
            border-color: var(--purple-dark);
        }

        .detail-actions {
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }

        .add-cart-button,
        .back-catalog-button {
            display: inline-block;
            padding: 13px 22px;
            border-radius: 6px;
            font-family: inherit;
            font-size: 13px;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: 0.3s;
        }

        .add-cart-button {
            border: 1px solid var(--purple-dark);
            background: var(--purple-dark);
            color: white;
        }

        .add-cart-button:hover {
            background: var(--text);
            border-color: var(--text);
        }

        .back-catalog-button {
            border: 1px solid var(--purple-dark);
            background: transparent;
            color: var(--purple-dark);
        }

        .back-catalog-button:hover {
            background: var(--lilac);
            color: var(--text);
        }

        .detail-message {
            color: var(--muted);
            font-size: 13px;
            margin-bottom: 18px;
        }

        @media (max-width: 750px) {
            .book-detail-page {
                padding: 35px 6%;
            }

            .book-detail-container {
                flex-direction: column;
                align-items: center;
                padding: 25px;
                gap: 30px;
            }

            .book-detail-image {
                width: 100%;
                max-width: 300px;
            }

            .book-detail-info {
                width: 100%;
            }

            .book-detail-info h1 {
                font-size: 27px;
            }
        }
    </style>
</head>

<body>

<header class="navbar">
    <a href="index.php" class="logo">LITERA</a>

    <nav>
        <a href="index.php">Beranda</a>
        <a href="katalog.php">Katalog</a>
        <a href="index.php#tentang">Tentang</a>
    </nav>

    <div class="nav-button">
        <?php if (isset($_SESSION['id_user'])): ?>
            <a href="keranjang.php">Keranjang (<?= $jumlahKeranjang; ?>)</a>
            <a href="profil.php">Profil</a>
            <a href="logout.php">Keluar</a>
        <?php else: ?>
            <a href="login.php">Masuk</a>
            <a href="register.php">Daftar</a>
        <?php endif; ?>
    </div>
</header>

<main class="book-detail-page">

    <div class="book-detail-container">

        <div class="book-detail-image">
            <?php if ($gambar !== ''): ?>
                <img src="<?= htmlspecialchars($gambar); ?>"
                     alt="<?= htmlspecialchars($buku['judul']); ?>">
            <?php else: ?>
                <div class="no-cover">Cover buku belum tersedia</div>
            <?php endif; ?>
        </div>

        <div class="book-detail-info">

            <span class="category">
                <?= htmlspecialchars($buku['kategori']); ?>
            </span>

            <h1><?= htmlspecialchars($buku['judul']); ?></h1>

            <p class="author">
                Penulis: <?= htmlspecialchars($buku['penulis']); ?>
            </p>

            <p class="price">
                Rp <?= number_format((float) $buku['harga'], 0, ',', '.'); ?>
            </p>

            <div class="description">
                <?= nl2br(htmlspecialchars($buku['deskripsi'] ?? 'Belum ada deskripsi buku.')); ?>
            </div>

            <p class="book-stock">
                Stok tersedia: <?= $stok; ?> buku
            </p>

            <?php if ($stok > 0): ?>

                <?php if (isset($_SESSION['id_user']) && $_SESSION['role'] === 'admin'): ?>

                    <p class="detail-message">
                        Admin tidak dapat menambahkan buku ke keranjang.
                    </p>

                    <a href="katalog.php" class="back-catalog-button">
                        Kembali ke Katalog
                    </a>

                <?php else: ?>

                    <form action="keranjang.php" method="POST">

                        <input type="hidden" name="id_buku" value="<?= $id_buku; ?>">

                        <div class="quantity-group">
                            <label for="jumlah">Jumlah buku</label>
                            <input type="number" name="jumlah" id="jumlah"
                                   value="1" min="1" max="<?= $stok; ?>" required>
                        </div>

                        <div class="detail-actions">
                            <button type="submit" name="tambah" class="add-cart-button">
                                Tambah ke Keranjang
                            </button>

                            <a href="katalog.php" class="back-catalog-button">
                                Kembali ke Katalog
                            </a>
                        </div>

                    </form>

                <?php endif; ?>

            <?php else: ?>

                <p class="detail-message">Maaf, buku ini sedang habis.</p>

                <a href="katalog.php" class="back-catalog-button">
                    Kembali ke Katalog
                </a>

            <?php endif; ?>

        </div>

    </div>

</main>

</body>
</html>
