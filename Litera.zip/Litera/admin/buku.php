
<?php
require_once '../koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$query = mysqli_query($conn, "SELECT * FROM buku ORDER BY dibuat_pada DESC");

if (!$query) {
    die("Gagal mengambil data buku: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Buku - LITERA</title>
    <link rel="stylesheet" href="../style.css?v=14">
</head>
<body>

<header class="navbar">
    <a href="../index.php" class="logo">LITERA<span>.</span></a>

    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="buku.php">Kelola Buku</a>
        <a href="kategori.php">Kelola Kategori</a>
        <a href="pesanan.php">Pesanan</a>
    </nav>

    <div class="nav-button">
        <a href="logout.php" class="btn-primary">Keluar</a>
    </div>
</header>

<main class="admin-page">

    <section class="admin-heading">
        <p class="eyebrow">PENGELOLAAN KOLEKSI</p>
        <h1>Kelola <span>Buku.</span></h1>
        <p>Atur dan perbarui koleksi buku yang tersedia di LITERA.</p>
    </section>

    <section class="book-management">

        <div class="book-management-top">
            <div>
                <h2>Daftar Buku</h2>
                <p>Kelola koleksi buku toko kamu.</p>
            </div>

            <div style="display:flex; gap:10px; flex-wrap:wrap;">
                <a href="kategori.php" class="btn-primary">
                    Kelola Kategori
                </a>

                <a href="tambah_buku.php" class="btn-primary">
                    + Tambah Buku
                </a>
            </div>
        </div>

        <div class="book-table-wrapper">
            <table class="book-table">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Gambar</th>
                        <th>Judul Buku</th>
                        <th>Penulis</th>
                        <th>Kategori</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (mysqli_num_rows($query) > 0): ?>
                        <?php $no = 1; ?>

                        <?php while ($buku = mysqli_fetch_assoc($query)): ?>
                            <tr>
                                <td><?= $no++; ?></td>

                                <td>
                                    <?php if (!empty($buku['gambar'])): ?>
                                        <img
                                            src="../uploads/<?= htmlspecialchars($buku['gambar']); ?>"
                                            class="book-table-image"
                                            alt="Sampul buku"
                                        >
                                    <?php else: ?>
                                        <span class="no-book-image">-</span>
                                    <?php endif; ?>
                                </td>

                                <td><?= htmlspecialchars($buku['judul']); ?></td>
                                <td><?= htmlspecialchars($buku['penulis']); ?></td>
                                <td><?= htmlspecialchars($buku['kategori']); ?></td>

                                <td>
                                    Rp <?= number_format($buku['harga'], 0, ',', '.'); ?>
                                </td>

                                <td><?= (int) $buku['stok']; ?></td>

                                <td>
                                    <div class="book-actions">
                                        <a href="edit_buku.php?id=<?= $buku['id_buku']; ?>" class="edit-book">
                                            Edit
                                        </a>

                                        <a
                                            href="hapus_buku.php?id=<?= $buku['id_buku']; ?>"
                                            class="delete-book"
                                            onclick="return confirm('Yakin ingin menghapus buku ini?')"
                                        >
                                            Hapus
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>

                    <?php else: ?>
                        <tr>
                            <td colspan="8" style="text-align:center;">
                                Belum ada buku.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </section>

</main>

<footer>
    <a href="../index.php" class="logo">LITERA<span>.</span></a>
    <p>Temukan cerita, ciptakan kenangan.</p>
    <small>© 2026 LITERA. Semua hak dilindungi.</small>
</footer>

</body>
</html>
