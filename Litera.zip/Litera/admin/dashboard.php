<?php
require_once '../koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Menghitung pesanan berdasarkan status
$queryStatus = mysqli_query($conn, "
    SELECT
        SUM(LOWER(TRIM(status)) = 'diproses') AS diproses,
        SUM(LOWER(TRIM(status)) = 'diantar') AS diantar,
        SUM(LOWER(TRIM(status)) = 'selesai') AS selesai
    FROM pesanan
");

$status = mysqli_fetch_assoc($queryStatus);

$diproses = $status['diproses'] ?? 0;
$diantar = $status['diantar'] ?? 0;
$selesai = $status['selesai'] ?? 0;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - LITERA</title>
    <link rel="stylesheet" href="../style.css?v=13">
</head>
<body>

<header class="navbar">

    <a href="../index.php" class="logo">
        LITERA<span>.</span>
    </a>

   <nav>
    <a href="dashboard.php">Dashboard</a>
    <a href="buku.php">Kelola Buku</a>
    <a href="pesanan.php">Pesanan</a>
    <a href="pesan.php">Pesan Pengguna</a>
</nav>

    <div class="nav-button">
        <a href="logout.php" class="btn-primary">Keluar</a>
    </div>

</header>

<main class="admin-page">

    <section class="admin-heading">
        <p class="eyebrow">HALAMAN ADMINISTRATOR</p>

        <h1>
            Selamat Datang di <span>LITERA.</span>
        </h1>

        <p>
            Kelola toko buku dan pantau aktivitas LITERA di sini.
        </p>
    </section>


    <!-- STATISTIK PESANAN -->

    <section class="admin-stats">

        <div class="admin-stat">
            <span>Pesanan Diproses</span>
            <h2><?= $diproses; ?></h2>
            <p>Pesanan sedang diproses</p>
        </div>

        <div class="admin-stat">
            <span>Pesanan Diantar</span>
            <h2><?= $diantar; ?></h2>
            <p>Pesanan dalam pengiriman</p>
        </div>

        <div class="admin-stat">
            <span>Pesanan Selesai</span>
            <h2><?= $selesai; ?></h2>
            <p>Pesanan telah selesai</p>
        </div>

    </section>


    <!-- MENU ADMIN -->

    <section class="admin-menu">

        <div class="admin-menu-heading">
            <p class="eyebrow">PENGELOLAAN TOKO</p>
            <h2>Menu Admin</h2>
            <p>Kelola seluruh aktivitas toko buku LITERA.</p>
        </div>

        <div class="admin-menu-grid">

            <a href="buku.php" class="admin-menu-card">

                <div class="admin-menu-icon">📚</div>

                <h3>Kelola Buku</h3>

                <p>
                    Tambah, edit, dan hapus koleksi buku.
                </p>

                <span>Kelola Sekarang →</span>

            </a>


            <a href="pesanan.php" class="admin-menu-card">

                <div class="admin-menu-icon">🛍️</div>

                <h3>Kelola Pesanan</h3>

                <p>
                    Lihat pesanan dan bukti pembayaran pelanggan.
                </p>

                <span>Lihat Pesanan →</span>

            </a>


            <a href="pengguna.php" class="admin-menu-card">

                <div class="admin-menu-icon">👥</div>

                <h3>Data Pengguna</h3>

                <p>
                    Lihat daftar akun pengguna LITERA.
                </p>

                <span>Lihat Pengguna →</span>

            </a>


            <a href="laporan.php" class="admin-menu-card">

                <div class="admin-menu-icon">📊</div>

                <h3>Laporan Penjualan</h3>

                <p>
                    Pantau ringkasan transaksi dan penjualan.
                </p>

                <span>Lihat Laporan →</span>

            </a>

        </div>

    </section>

</main>


<footer>
    <a href="../index.php" class="logo">
        LITERA<span>.</span>
    </a>

    <p>Temukan cerita, ciptakan kenangan.</p>

    <small>© 2026 LITERA. Semua hak dilindungi.</small>
</footer>

</body>
</html>