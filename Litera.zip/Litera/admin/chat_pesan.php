```php
<?php
require_once '../koneksi.php';

if (!isset($_SESSION['id_user']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$id_user = (int)($_GET['id'] ?? 0);

$user = mysqli_query($conn, "
    SELECT id_user, nama
    FROM users
    WHERE id_user = $id_user
");

$dataUser = mysqli_fetch_assoc($user);

if (!$dataUser) {
    header("Location: pesan.php");
    exit;
}

// Ambil pesan otomatis
if (isset($_GET['ambil'])) {
    mysqli_query($conn, "
        UPDATE chat_pesan
        SET dibaca = 1
        WHERE id_user = $id_user
        AND pengirim = 'user'
    ");

    $result = mysqli_query($conn, "
        SELECT id_pesan, pengirim, isi_pesan, tanggal_kirim
        FROM chat_pesan
        WHERE id_user = $id_user
        ORDER BY id_pesan ASC
    ");

    $pesan = [];

    while ($row = mysqli_fetch_assoc($result)) {
        $pesan[] = $row;
    }

    header('Content-Type: application/json');
    echo json_encode($pesan);
    exit;
}

// Kirim balasan admin
if (isset($_POST['kirim'])) {
    $isi = trim($_POST['isi_pesan']);

    if ($isi !== '') {
        $stmt = mysqli_prepare($conn, "
            INSERT INTO chat_pesan
            (id_user, pengirim, isi_pesan, dibaca)
            VALUES (?, 'admin', ?, 0)
        ");

        mysqli_stmt_bind_param($stmt, "is", $id_user, $isi);
        mysqli_stmt_execute($stmt);
    }

    header("Location: chat_admin.php?id=" . $id_user);
    exit;
}

// Ambil riwayat chat
mysqli_query($conn, "
    UPDATE chat_pesan
    SET dibaca = 1
    WHERE id_user = $id_user
    AND pengirim = 'user'
");

$query = mysqli_query($conn, "
    SELECT id_pesan, pengirim, isi_pesan, tanggal_kirim
    FROM chat_pesan
    WHERE id_user = $id_user
    ORDER BY id_pesan ASC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Balas Pesan - LITERA</title>
    <link rel="stylesheet" href="../style.css">

    <style>
        .chat-page {
            max-width: 850px;
            margin: 40px auto;
            padding: 20px;
        }

        .chat-container {
            background: white;
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0,0,0,.06);
        }

        .chat-header {
            background: #947ba9;
            color: white;
            padding: 22px;
        }

        .chat-body {
            height: 430px;
            overflow-y: auto;
            padding: 20px;
            background: #faf7fc;
        }

        .chat-message {
            display: flex;
            margin-bottom: 15px;
        }

        .chat-message.admin {
            justify-content: flex-end;
        }

        .chat-bubble {
            max-width: 75%;
            padding: 12px 16px;
            background: white;
            color: #51465a;
            border-radius: 12px;
            overflow-wrap: anywhere;
            box-shadow: 0 2px 7px rgba(0,0,0,.04);
        }

        .chat-message.admin .chat-bubble {
            background: #e9dff2;
        }

        .chat-time {
            display: block;
            margin-top: 7px;
            font-size: 10px;
            color: #8c8193;
        }

        .chat-form {
            display: flex;
            gap: 10px;
            padding: 18px;
            border-top: 1px solid #eee;
        }

        .chat-form textarea {
            flex: 1;
            min-width: 0;
            height: 48px;
            padding: 13px;
            border: 1px solid #ddd;
            border-radius: 9px;
            resize: none;
            font-family: inherit;
        }

        .chat-form button {
            border: none;
            cursor: pointer;
        }
    </style>
</head>

<body>

<header class="navbar">
    <a href="dashboard.php" class="logo">LITERA<span>.</span></a>

    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="pesan.php">Kembali ke Pesan</a>
    </nav>

    <div class="nav-button">
        <a href="../logout.php" class="btn-primary">Keluar</a>
    </div>
</header>

<main class="chat-page">

    <div class="chat-container">

        <div class="chat-header">
            <h2><?= htmlspecialchars($dataUser['nama']); ?></h2>
            <p>Percakapan dengan pengguna LITERA</p>
        </div>

        <div class="chat-body" id="chatBody">

            <?php while ($row = mysqli_fetch_assoc($query)): ?>
                <div class="chat-message <?= $row['pengirim'] === 'admin' ? 'admin' : 'user'; ?>">
                    <div class="chat-bubble">
                        <?= nl2br(htmlspecialchars($row['isi_pesan'])); ?>

                        <span class="chat-time">
                            <?= date('d/m/Y H:i', strtotime($row['tanggal_kirim'])); ?>
                            · <?= $row['pengirim'] === 'admin' ? 'Admin' : 'Pengguna'; ?>
                        </span>
                    </div>
                </div>
            <?php endwhile; ?>

        </div>

        <form method="POST" class="chat-form">
            <textarea name="isi_pesan" placeholder="Tulis balasan..." required></textarea>
            <button type="submit" name="kirim" class="btn-primary">Kirim</button>
        </form>

    </div>

</main>

<script>
const chatBody = document.getElementById('chatBody');
let pesanTerakhir = '';

function ambilPesan() {
    fetch('chat_admin.php?id=<?= $id_user; ?>&ambil=1')
        .then(response => response.json())
        .then(data => {
            const versi = JSON.stringify(data);

            if (versi === pesanTerakhir) return;

            pesanTerakhir = versi;
            chatBody.innerHTML = '';

            data.forEach(pesan => {
                const baris = document.createElement('div');
                baris.className = 'chat-message ' +
                    (pesan.pengirim === 'admin' ? 'admin' : 'user');

                const bubble = document.createElement('div');
                bubble.className = 'chat-bubble';

                const isi = document.createElement('div');
                isi.textContent = pesan.isi_pesan;

                const waktu = document.createElement('span');
                waktu.className = 'chat-time';
                waktu.textContent = pesan.tanggal_kirim +
                    ' · ' + (pesan.pengirim === 'admin' ? 'Admin' : 'Pengguna');

                bubble.appendChild(isi);
                bubble.appendChild(waktu);
                baris.appendChild(bubble);
                chatBody.appendChild(baris);
            });

            chatBody.scrollTop = chatBody.scrollHeight;
        })
        .catch(error => console.log(error));
}

chatBody.scrollTop = chatBody.scrollHeight;
ambilPesan();
setInterval(ambilPesan, 3000);
</script>

</body>
</html>
```