
<?php
require_once '../koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$query = mysqli_query($conn, "
    SELECT id_user, nama, email, dibuat_pada
    FROM users
    WHERE role = 'user'
    ORDER BY dibuat_pada DESC
");

if (!$query) {
    die("Gagal mengambil data pengguna: " . mysqli_error($conn));
}

$total_pengguna = mysqli_num_rows($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pengguna - LITERA</title>

    <link rel="stylesheet" href="../style.css?v=108">

    <style>
        .user-page {
            width: 100%;
            padding: 65px 35px;
            box-sizing: border-box;
        }

        .user-container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
        }

        .user-heading {
            text-align: center;
            margin-bottom: 40px;
        }

        .user-heading span {
            color: #9b82b8;
            font-size: 14px;
            font-weight: bold;
            letter-spacing: 3px;
        }

        .user-heading h1 {
            color: #493b59;
            font-family: Georgia, serif;
            font-size: 46px;
            margin: 15px 0;
        }

        .user-heading p {
            color: #81718f;
            font-size: 16px;
        }

        .user-summary {
            background: #eee5f8;
            border: 1px solid #e0d2ed;
            border-radius: 10px;
            padding: 25px 30px;
            margin-bottom: 30px;
            color: #80639e;
            font-size: 16px;
        }

        .user-summary strong {
            display: block;
            color: #493b59;
            font-family: Georgia, serif;
            font-size: 32px;
            margin-top: 8px;
        }

        .user-card {
            background: #fdfaff;
            border: 1px solid #e0d2ed;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 8px 25px rgba(91, 68, 117, 0.08);
        }

        .user-table-scroll {
            width: 100%;
            overflow-x: auto;
        }

        .user-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 650px;
        }

        .user-table th {
            background: #d9c8eb;
            color: #493b59;
            padding: 18px 15px;
            text-align: center;
            font-size: 14px;
        }

        .user-table td {
            padding: 20px 15px;
            text-align: center;
            color: #71617f;
            border-bottom: 1px solid #eee5f5;
            font-size: 14px;
        }

        .user-table td strong {
            color: #493b59;
        }

        .user-role {
            display: inline-block;
            padding: 7px 15px;
            background: #eee5f8;
            color: #80639e;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }

        @media (max-width: 768px) {
            .user-page {
                padding: 40px 15px;
            }

            .user-heading h1 {
                font-size: 36px;
            }

            .user-card {
                padding: 15px;
            }
        }
    </style>
</head>

<body>

<header class="navbar">
    <a href="../index.php" class="logo">LITERA<span>.</span></a>

    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="buku.php">Kelola Buku</a>
        <a href="pesanan.php">Pesanan</a>
        <a href="pengguna.php">Pengguna</a>
    </nav>
</header>

<main class="user-page">
    <div class="user-container">

        <div class="user-heading">
            <span>PENGELOLAAN TOKO</span>
            <h1>Data Pengguna</h1>
            <p>Informasi pelanggan yang telah terdaftar di LITERA.</p>
        </div>

        <div class="user-summary">
            Total Pengguna Terdaftar
            <strong><?= $total_pengguna; ?></strong>
        </div>

        <div class="user-card">
            <div class="user-table-scroll">
                <table class="user-table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Pengguna</th>
                            <th>Email</th>
                            <th>Tanggal Bergabung</th>
                            <th>Role</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php if ($total_pengguna > 0): ?>
                            <?php $no = 1; ?>
                            <?php while ($user = mysqli_fetch_assoc($query)): ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td>
                                        <strong><?= htmlspecialchars($user['nama']); ?></strong>
                                    </td>
                                    <td><?= htmlspecialchars($user['email']); ?></td>
                                    <td>
                                        <?= date('d/m/Y', strtotime($user['dibuat_pada'])); ?>
                                    </td>
                                    <td>
                                        <span class="user-role">Pelanggan</span>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5">Belum ada pengguna terdaftar.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</main>

</body>
</html>
