
<?php
require_once '../koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: pesanan.php");
    exit;
}

$id_pesanan = (int) $_GET['id'];

// Ambil informasi pesanan dan pelanggan
$stmt = mysqli_prepare($conn, "
    SELECT pesanan.*, users.nama, users.email
    FROM pesanan
    LEFT JOIN users ON pesanan.id_user = users.id_user
    WHERE pesanan.id_pesanan = ?
");

mysqli_stmt_bind_param($stmt, "i", $id_pesanan);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$pesanan = mysqli_fetch_assoc($result);

mysqli_stmt_close($stmt);

if (!$pesanan) {
    die("Pesanan tidak ditemukan.");
}

// Ambil daftar buku dalam pesanan
$stmt_detail = mysqli_prepare($conn, "
    SELECT *
    FROM detail_pesanan
    WHERE id_pesanan = ?
");

mysqli_stmt_bind_param($stmt_detail, "i", $id_pesanan);
mysqli_stmt_execute($stmt_detail);

$detail = mysqli_stmt_get_result($stmt_detail);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Pesanan - LITERA</title>

    <link rel="stylesheet" href="../style.css?v=104">

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            background: #faf6ff;
            color: #493b59;
        }

        .detail-page {
            width: 100%;
            min-height: 100vh;
            padding: 55px 25px;
            background: #faf6ff;
        }

        .detail-container {
            max-width: 1100px;
            margin: auto;
        }

        .detail-heading {
            text-align: center;
            margin-bottom: 35px;
        }

        .detail-heading span {
            color: #9e80c0;
            letter-spacing: 3px;
            font-size: 13px;
            font-weight: bold;
        }

        .detail-heading h1 {
            font-family: Georgia, serif;
            color: #493b59;
            font-size: 42px;
            margin: 15px 0;
        }

        .detail-heading p {
            color: #81718f;
        }

        .detail-card {
            background: #ffffff;
            border: 1px solid #e8def2;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 25px;
            box-shadow: 0 8px 25px rgba(128, 99, 158, 0.06);
        }

        .detail-card h2 {
            color: #80639e;
            font-family: Georgia, serif;
            font-size: 23px;
            margin-top: 0;
            margin-bottom: 22px;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 22px;
        }

        .info-item {
            color: #81718f;
            font-size: 14px;
        }

        .info-item strong {
            display: block;
            color: #493b59;
            margin-top: 7px;
            font-size: 16px;
        }

        .detail-table-wrapper {
            width: 100%;
            overflow-x: auto;
        }

        .detail-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 550px;
        }

        .detail-table th {
            background: #b69bd3;
            color: white;
            padding: 15px;
            text-align: center;
        }

        .detail-table td {
            padding: 16px;
            border-bottom: 1px solid #eee5f8;
            text-align: center;
            color: #493b59;
        }

        .total-box {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid #e8def2;
            color: #493b59;
            font-size: 18px;
            font-weight: bold;
        }

        .total-box span:last-child {
            color: #80639e;
        }

        .payment-proof {
            margin-top: 15px;
        }

        .payment-proof p {
            color: #81718f;
        }

        .payment-proof img {
            display: block;
            max-width: 350px;
            width: 100%;
            height: auto;
            border: 1px solid #e8def2;
            border-radius: 10px;
            margin-top: 12px;
        }

        .no-proof {
            color: #81718f;
            font-size: 14px;
        }

        .back-button {
            display: inline-block;
            padding: 13px 24px;
            background: #b69bd3;
            color: white;
            text-decoration: none;
            border-radius: 9px;
            font-weight: bold;
            transition: 0.3s;
        }

        .back-button:hover {
            background: #9e80c0;
        }

        @media (max-width: 600px) {
            .detail-page {
                padding: 35px 15px;
            }

            .detail-card {
                padding: 20px;
            }

            .info-grid {
                grid-template-columns: 1fr;
            }

            .detail-heading h1 {
                font-size: 34px;
            }
        }
    </style>
</head>

<body>

<header class="navbar">
    <a href="../index.php" class="logo">LITERA<span>.</span></a>

    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="buku.php">Kelola Buku</a>
        <a href="pesanan.php">Pesanan</a>
    </nav>
</header>

<main class="detail-page">
    <div class="detail-container">

        <div class="detail-heading">
            <span>PENGELOLAAN TOKO</span>
            <h1>Detail Pesanan</h1>
            <p>Informasi lengkap transaksi pelanggan LITERA.</p>
        </div>

        <div class="detail-card">
            <h2>Informasi Pesanan</h2>

            <div class="info-grid">
                <div class="info-item">
                    Kode Pesanan
                    <strong><?= htmlspecialchars($pesanan['kode_pesanan']); ?></strong>
                </div>

                <div class="info-item">
                    Tanggal Pesanan
                    <strong><?= date('d/m/Y H:i', strtotime($pesanan['dibuat_pada'])); ?></strong>
                </div>

                <div class="info-item">
                    Nama Pelanggan
                    <strong><?= htmlspecialchars($pesanan['nama'] ?? '-'); ?></strong>
                </div>

                <div class="info-item">
                    Email
                    <strong><?= htmlspecialchars($pesanan['email'] ?? '-'); ?></strong>
                </div>

                <div class="info-item">
                    Metode Pembayaran
                    <strong><?= htmlspecialchars($pesanan['metode_pembayaran'] ?? '-'); ?></strong>
                </div>

                <div class="info-item">
                    Status Pesanan
                    <strong><?= htmlspecialchars($pesanan['status']); ?></strong>
                </div>

                <div class="info-item">
                    Alamat Pengiriman
                    <strong><?= nl2br(htmlspecialchars($pesanan['alamat'] ?? '-')); ?></strong>
                </div>

                <div class="info-item">
                    Catatan
                    <strong><?= htmlspecialchars($pesanan['catatan'] ?: '-'); ?></strong>
                </div>
            </div>
        </div>

        <div class="detail-card">
            <h2>Buku yang Dibeli</h2>

            <div class="detail-table-wrapper">
                <table class="detail-table">
                    <thead>
                        <tr>
                            <th>Judul Buku</th>
                            <th>Harga</th>
                            <th>Jumlah</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php if (mysqli_num_rows($detail) > 0): ?>
                            <?php while ($buku = mysqli_fetch_assoc($detail)): ?>
                                <tr>
                                    <td><?= htmlspecialchars($buku['judul_buku']); ?></td>
                                    <td>
                                        Rp<?= number_format($buku['harga'], 0, ',', '.'); ?>
                                    </td>
                                    <td><?= (int) $buku['jumlah']; ?></td>
                                    <td>
                                        Rp<?= number_format($buku['subtotal'], 0, ',', '.'); ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4">Belum ada detail buku.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="total-box">
                <span>Total Pembayaran</span>
                <span>
                    Rp<?= number_format($pesanan['total'], 0, ',', '.'); ?>
                </span>
            </div>
        </div>

        <div class="detail-card">
            <h2>Bukti Pembayaran</h2>

            <?php if (!empty($pesanan['bukti_pembayaran'])): ?>
                <?php
                $nama_file = basename($pesanan['bukti_pembayaran']);
                $lokasi_bukti = '../uploads/' . $nama_file;
                ?>

                <?php if (file_exists(__DIR__ . '/../uploads/' . $nama_file)): ?>
                    <div class="payment-proof">
                        <p>Bukti transfer pelanggan:</p>
                        <a href="<?= htmlspecialchars($lokasi_bukti); ?>" target="_blank">
                            <img
                                src="<?= htmlspecialchars($lokasi_bukti); ?>"
                                alt="Bukti Pembayaran">
                        </a>
                    </div>
                <?php else: ?>
                    <p class="no-proof">File bukti pembayaran tidak ditemukan.</p>
                <?php endif; ?>

            <?php else: ?>
                <p class="no-proof">Pelanggan belum mengunggah bukti pembayaran.</p>
            <?php endif; ?>
        </div>

        <a href="pesanan.php" class="back-button">← Kembali ke Pesanan</a>

    </div>
</main>

</body>
</html>

<?php
mysqli_stmt_close($stmt_detail);
?>
