
<?php
require_once '../koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$ringkasan = mysqli_query($conn, "
    SELECT COUNT(*) AS jumlah_pesanan,
           COALESCE(SUM(total), 0) AS total_penjualan
    FROM pesanan
    WHERE status = 'Selesai'
");

$data = mysqli_fetch_assoc($ringkasan);

$query = mysqli_query($conn, "
    SELECT pesanan.*, users.nama
    FROM pesanan
    LEFT JOIN users ON pesanan.id_user = users.id_user
    WHERE pesanan.status = 'Selesai'
    ORDER BY pesanan.dibuat_pada DESC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Penjualan LITERA</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            color: #493b59;
            padding: 35px;
            background: white;
        }

        .header {
            text-align: center;
            margin-bottom: 35px;
        }

        .header h1 {
            font-family: Georgia, serif;
            font-size: 32px;
            margin-bottom: 8px;
        }

        .header p {
            color: #81718f;
            margin: 5px;
        }

        .summary {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
        }

        .summary-box {
            flex: 1;
            padding: 20px;
            background: #f5effb;
            border: 1px solid #d9c8eb;
            border-radius: 8px;
        }

        .summary-box p {
            margin: 0 0 10px;
            color: #80639e;
        }

        .summary-box h2 {
            margin: 0;
            font-size: 23px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        th {
            background: #d9c8eb;
            color: #493b59;
        }

        th, td {
            border: 1px solid #d9c8eb;
            padding: 12px 10px;
            text-align: center;
            font-size: 12px;
        }

        .footer {
            margin-top: 40px;
            text-align: right;
            font-size: 13px;
        }

        .print-button {
            background: #b69bd3;
            color: white;
            border: none;
            padding: 12px 22px;
            border-radius: 5px;
            cursor: pointer;
            margin-bottom: 25px;
            font-size: 14px;
        }

        @media print {
            body {
                padding: 0;
            }

            .print-button {
                display: none;
            }

            .summary-box {
                print-color-adjust: exact;
                -webkit-print-color-adjust: exact;
            }

            th {
                print-color-adjust: exact;
                -webkit-print-color-adjust: exact;
            }
        }
    </style>
</head>

<body>

<button class="print-button" onclick="window.print()">
    Cetak / Simpan PDF
</button>

<div class="header">
    <h1>LITERA.</h1>
    <p>Laporan Penjualan Toko Buku LITERA</p>
    <p>Tanggal Cetak: <?= date('d/m/Y'); ?></p>
</div>

<div class="summary">
    <div class="summary-box">
        <p>Total Penjualan</p>
        <h2>Rp<?= number_format($data['total_penjualan'], 0, ',', '.'); ?></h2>
    </div>

    <div class="summary-box">
        <p>Jumlah Pesanan Selesai</p>
        <h2><?= number_format($data['jumlah_pesanan']); ?> Pesanan</h2>
    </div>
</div>

<h3>Rincian Transaksi</h3>

<table>
    <thead>
        <tr>
            <th>No</th>
            <th>Kode Pesanan</th>
            <th>Nama Pelanggan</th>
            <th>Tanggal</th>
            <th>Total</th>
            <th>Status</th>
        </tr>
    </thead>

    <tbody>
        <?php if (mysqli_num_rows($query) > 0): ?>
            <?php $no = 1; ?>

            <?php while ($pesanan = mysqli_fetch_assoc($query)): ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= htmlspecialchars($pesanan['kode_pesanan']); ?></td>
                    <td><?= htmlspecialchars($pesanan['nama'] ?? '-'); ?></td>
                    <td><?= date('d/m/Y', strtotime($pesanan['dibuat_pada'])); ?></td>
                    <td>Rp<?= number_format($pesanan['total'], 0, ',', '.'); ?></td>
                    <td>Selesai</td>
                </tr>
            <?php endwhile; ?>

        <?php else: ?>
            <tr>
                <td colspan="6">Belum ada transaksi selesai.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<div class="footer">
    <p>Admin LITERA</p>
    <br><br>
    <strong>LITERA BOOKSTORE</strong>
</div>

</body>
</html>
