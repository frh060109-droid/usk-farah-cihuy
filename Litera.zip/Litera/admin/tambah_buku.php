<?php
require_once '../koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$pesan = "";

if (isset($_POST['simpan'])) {
    $judul = mysqli_real_escape_string($conn, $_POST['judul']);
    $penulis = mysqli_real_escape_string($conn, $_POST['penulis']);
    $kategori = mysqli_real_escape_string($conn, $_POST['kategori']);
    $harga = (int) $_POST['harga'];
    $stok = (int) $_POST['stok'];
    $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);

    if (!isset($_FILES['gambar']) || $_FILES['gambar']['error'] !== 0) {
        $pesan = "Silakan pilih gambar buku.";
    } else {
        $namaFile = $_FILES['gambar']['name'];
        $tmpFile = $_FILES['gambar']['tmp_name'];
        $ukuranFile = $_FILES['gambar']['size'];

        $ekstensi = strtolower(pathinfo($namaFile, PATHINFO_EXTENSION));
        $ekstensiDiizinkan = ['jpg', 'jpeg', 'png', 'webp'];

        if (!in_array($ekstensi, $ekstensiDiizinkan)) {
            $pesan = "Format gambar harus JPG, JPEG, PNG, atau WEBP.";
        } elseif ($ukuranFile > 2 * 1024 * 1024) {
            $pesan = "Ukuran gambar maksimal 2 MB.";
        } else {
            $folderUpload = '../uploads/';

            if (!is_dir($folderUpload)) {
                mkdir($folderUpload, 0777, true);
            }

            $gambarBaru = uniqid('buku_') . '.' . $ekstensi;

            if (move_uploaded_file($tmpFile, $folderUpload . $gambarBaru)) {
                $query = mysqli_query($conn, "
                    INSERT INTO buku
                    (judul, penulis, kategori, harga, stok, deskripsi, gambar, dibuat_pada)
                    VALUES
                    ('$judul', '$penulis', '$kategori', '$harga', '$stok', '$deskripsi', '$gambarBaru', NOW())
                ");

                if ($query) {
                    header("Location: buku.php?pesan=ditambahkan");
                    exit;
                } else {
                    unlink($folderUpload . $gambarBaru);
                    $pesan = "Gagal menyimpan buku ke database.";
                }
            } else {
                $pesan = "Gagal mengunggah gambar.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Buku - LITERA</title>
    <link rel="stylesheet" href="../style.css?v=15">
</head>
<body>

<header class="navbar">
    <a href="../index.php" class="logo">LITERA<span>.</span></a>

    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="buku.php">Kelola Buku</a>
        <a href="pesanan.php">Pesanan</a>
    </nav>

    <div class="nav-button">
        <a href="logout.php" class="btn-primary">Keluar</a>
    </div>
</header>

<main class="book-form-page">

    <div class="book-form-heading">
        <p class="eyebrow">PENGELOLAAN KOLEKSI</p>
        <h1>Tambah Buku</h1>
        <p>Tambahkan buku baru ke dalam koleksi LITERA.</p>
    </div>

    <form method="POST" enctype="multipart/form-data" class="book-form-card">

        <?php if ($pesan): ?>
            <div class="form-error">
                <?= htmlspecialchars($pesan); ?>
            </div>
        <?php endif; ?>

        <div class="book-form-grid">

            <div class="book-form-group">
                <label>Judul Buku</label>
                <input type="text" name="judul" placeholder="Masukkan judul buku" required>
            </div>

            <div class="book-form-group">
                <label>Penulis</label>
                <input type="text" name="penulis" placeholder="Nama penulis" required>
            </div>

            <div class="book-form-group">
                <label>Kategori</label>
                <select name="kategori" required>
                    <option value="">Pilih kategori</option>
                    <option value="Novel">Novel</option>
                    <option value="Bisnis">Bisnis</option>
                    <option value="Pengembangan Diri">Pengembangan Diri</option>
                </select>
            </div>

            <div class="book-form-group">
                <label>Harga Buku</label>
                <input type="number" name="harga" min="1" placeholder="Contoh: 85000" required>
            </div>

            <div class="book-form-group">
                <label>Stok Buku</label>
                <input type="number" name="stok" min="0" placeholder="Jumlah stok" required>
            </div>

            <div class="book-form-group full-width">
                <label>Deskripsi Buku</label>
                <textarea name="deskripsi" rows="5" placeholder="Tuliskan deskripsi buku..." required></textarea>
            </div>

            <div class="book-form-group full-width">
                <label>Cover Buku</label>
                <input type="file" name="gambar" accept=".jpg,.jpeg,.png,.webp" required>
                <small>Format JPG, JPEG, PNG, atau WEBP. Maksimal 2 MB.</small>
            </div>

        </div>

        <div class="book-form-actions">
            <a href="buku.php" class="btn-cancel">Batal</a>
            <button type="submit" name="simpan" class="btn-primary">Simpan Buku</button>
        </div>

    </form>

</main>

</body>
</html>