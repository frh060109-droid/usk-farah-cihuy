
<?php
require_once '../koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$pesan = "";
$jenis_pesan = "";

// Status yang boleh diubah oleh admin
$status_valid = [
    'Menunggu Pembayaran',
    'Diproses',
    'Diantar',
    'Dibatalkan'
];

// Ubah status pesanan
if (isset($_POST['ubah_status'])) {
    $id_pesanan = (int) $_POST['id_pesanan'];
    $status = $_POST['status'];

    if (in_array($status, $status_valid, true)) {

        // Admin tidak boleh mengubah pesanan yang sudah selesai
        $cek = mysqli_prepare(
            $conn,
            "SELECT status FROM pesanan WHERE id_pesanan = ?"
        );

        mysqli_stmt_bind_param($cek, "i", $id_pesanan);
        mysqli_stmt_execute($cek);
        $hasil = mysqli_stmt_get_result($cek);
        $data = mysqli_fetch_assoc($hasil);
        mysqli_stmt_close($cek);

        if (!$data) {
            $pesan = "Pesanan tidak ditemukan.";
            $jenis_pesan = "error";
        } elseif ($data['status'] === 'Selesai') {
            $pesan = "Pesanan sudah selesai dikonfirmasi oleh pelanggan.";
            $jenis_pesan = "error";
        } else {
            $stmt = mysqli_prepare(
                $conn,
                "UPDATE pesanan SET status = ? WHERE id_pesanan = ?"
            );

            mysqli_stmt_bind_param($stmt, "si", $status, $id_pesanan);

            if (mysqli_stmt_execute($stmt)) {
                $pesan = "Status pesanan berhasil diperbarui.";
                $jenis_pesan = "success";
            } else {
                $pesan = "Gagal memperbarui status pesanan.";
                $jenis_pesan = "error";
            }

            mysqli_stmt_close($stmt);
        }

    } else {
        $pesan = "Status pesanan tidak valid.";
        $jenis_pesan = "error";
    }
}

// Ambil data pesanan
$query = mysqli_query($conn, "
    SELECT pesanan.*, users.nama
    FROM pesanan
    JOIN users ON pesanan.id_user = users.id_user
    ORDER BY pesanan.dibuat_pada DESC
");

if (!$query) {
    die("Gagal mengambil data pesanan: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pesanan - LITERA</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f8f5fc;
            color: #333;
            padding: 30px;
        }

        .container {
            max-width: 1200px;
            margin: auto;
        }

        .header {
            margin-bottom: 25px;
        }

        .header h2 {
            color: #72558e;
            margin-bottom: 8px;
        }

        .header p {
            color: #777;
            font-size: 14px;
        }

        .btn-kembali {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 16px;
            background: #8d70aa;
            color: white;
            text-decoration: none;
            border-radius: 7px;
            font-size: 13px;
        }

        .btn-kembali:hover {
            background: #72558e;
        }

        .pesan {
            padding: 12px 15px;
            border-radius: 7px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .success {
            background: #e5f5e9;
            color: #26733b;
        }

        .error {
            background: #fde8e8;
            color: #a83232;
        }

        .table-wrapper {
            background: white;
            border-radius: 12px;
            padding: 20px;
            overflow-x: auto;
            box-shadow: 0 3px 12px rgba(0,0,0,0.05);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 950px;
        }

        th {
            background: #eee6f5;
            color: #72558e;
            padding: 14px 12px;
            text-align: left;
            font-size: 13px;
        }

        td {
            padding: 14px 12px;
            border-bottom: 1px solid #eee;
            font-size: 13px;
            vertical-align: middle;
        }

        tr:hover {
            background: #fcfaff;
        }

        .bukti {
            display: inline-block;
            padding: 7px 10px;
            background: #eee6f5;
            color: #72558e;
            text-decoration: none;
            border-radius: 6px;
            font-size: 12px;
        }

        .bukti:hover {
            background: #dfd1ed;
        }

        .status-form {
            display: flex;
            gap: 7px;
            align-items: center;
        }

        select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 12px;
            background: white;
        }

        .btn-simpan {
            padding: 8px 11px;
            border: none;
            border-radius: 6px;
            background: #8d70aa;
            color: white;
            cursor: pointer;
            font-size: 12px;
        }

        .btn-simpan:hover {
            background: #72558e;
        }

        .btn-detail {
            display: inline-block;
            padding: 8px 11px;
            background: #f2eaf8;
            color: #72558e;
            text-decoration: none;
            border-radius: 6px;
            font-size: 12px;
        }

        .kosong {
            text-align: center;
            padding: 30px;
            color: #888;
        }

        .metode {
            color: #72558e;
            font-weight: bold;
        }

        .status-selesai {
            color: #26733b;
            font-weight: bold;
        }
    </style>
</head>

<body>

<div class="container">

    <a href="dashboard.php" class="btn-kembali">← Kembali ke Dashboard</a>

    <div class="header">
        <h2>Data Pesanan</h2>
        <p>Kelola pesanan dan perbarui status pembelian pelanggan.</p>
    </div>

    <?php if ($pesan !== ""): ?>
        <div class="pesan <?= $jenis_pesan; ?>">
            <?= htmlspecialchars($pesan); ?>
        </div>
    <?php endif; ?>

    <div class="table-wrapper">

        <table>
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Kode Pesanan</th>
                    <th>Nama Pelanggan</th>
                    <th>Tanggal</th>
                    <th>Total</th>
                    <th>Pembayaran</th>
                    <th>Bukti Pembayaran</th>
                    <th>Status</th>
                    <th>Detail</th>
                </tr>
            </thead>

            <tbody>

            <?php if (mysqli_num_rows($query) > 0): ?>

                <?php $no = 1; ?>

                <?php while ($pesanan = mysqli_fetch_assoc($query)): ?>

                    <tr>
                        <td><?= $no++; ?></td>

                        <td>
                            <?= htmlspecialchars($pesanan['kode_pesanan']); ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($pesanan['nama']); ?>
                        </td>

                        <td>
                            <?= date('d-m-Y', strtotime($pesanan['dibuat_pada'])); ?>
                        </td>

                        <td>
                            Rp<?= number_format($pesanan['total'], 0, ',', '.'); ?>
                        </td>

                        <td>
                            <?php if ($pesanan['metode_pembayaran'] === 'Transfer Bank'): ?>
                                <span class="metode">Transfer Bank</span>
                            <?php else: ?>
                                <span>Metode tidak valid</span>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php if (!empty($pesanan['bukti_pembayaran'])): ?>
                                <a
                                    href="../uploads/<?= rawurlencode(basename($pesanan['bukti_pembayaran'])); ?>"
                                    target="_blank"
                                    class="bukti"
                                >
                                    Lihat Bukti
                                </a>
                            <?php else: ?>
                                <span>-</span>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php if ($pesanan['status'] === 'Selesai'): ?>

                                <span class="status-selesai">
                                    Selesai (Dikonfirmasi User)
                                </span>

                            <?php else: ?>

                                <form method="POST" class="status-form">

                                    <input
                                        type="hidden"
                                        name="id_pesanan"
                                        value="<?= (int) $pesanan['id_pesanan']; ?>"
                                    >

                                    <select name="status" required>
                                        <?php foreach ($status_valid as $s): ?>
                                            <option
                                                value="<?= htmlspecialchars($s); ?>"
                                                <?= $pesanan['status'] === $s ? 'selected' : ''; ?>
                                            >
                                                <?= htmlspecialchars($s); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>

                                    <button
                                        type="submit"
                                        name="ubah_status"
                                        class="btn-simpan"
                                    >
                                        Simpan
                                    </button>

                                </form>

                            <?php endif; ?>
                        </td>

                        <td>
                            <a
                                href="detail_pesanan.php?id=<?= (int) $pesanan['id_pesanan']; ?>"
                                class="btn-detail"
                            >
                                Detail
                            </a>
                        </td>
                    </tr>

                <?php endwhile; ?>

            <?php else: ?>

                <tr>
                    <td colspan="9" class="kosong">
                        Belum ada pesanan.
                    </td>
                </tr>

            <?php endif; ?>

            </tbody>
        </table>

    </div>

</div>

</body>
</html>
