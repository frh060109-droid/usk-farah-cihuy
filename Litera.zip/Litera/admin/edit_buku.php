<?php
require_once '../koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: buku.php");
    exit;
}

$id = (int) $_GET['id'];

$queryBuku = mysqli_query($conn, "SELECT * FROM buku WHERE id_buku = $id");
$buku = mysqli_fetch_assoc($queryBuku);

if (!$buku) {
    header("Location: buku.php");
    exit;
}

$pesan = "";

if (isset($_POST['update'])) {
    $judul = mysqli_real_escape_string($conn, $_POST['judul']);
    $penulis = mysqli_real_escape_string($conn, $_POST['penulis']);
    $kategori = mysqli_real_escape_string($conn, $_POST['kategori']);
    $harga = (int) $_POST['harga'];
    $stok = (int) $_POST['stok'];
    $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);

    $gambar = $buku['gambar'];

    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] !== 4) {
        if ($_FILES['gambar']['error'] !== 0) {
            $pesan = "Gagal mengunggah gambar.";
        } else {
            $namaFile = $_FILES['gambar']['name'];
            $tmpFile = $_FILES['gambar']['tmp_name'];
            $ukuranFile = $_FILES['gambar']['size'];

            $ekstensi = strtolower(pathinfo($namaFile, PATHINFO_EXTENSION));
            $ekstensiDiizinkan = ['jpg', 'jpeg', 'png', 'webp'];

            if (!in_array($ekstensi, $ekstensiDiizinkan)) {
                $pesan = "Format gambar harus JPG, JPEG, PNG, atau WEBP.";
            } elseif ($ukuranFile > 2 * 1024 * 1024) {
                $pesan = "Ukuran gambar maksimal 2 MB.";
            } else {
                $folderUpload = '../uploads/';
                $gambarBaru = uniqid('buku_') . '.' . $ekstensi;

                if (move_uploaded_file($tmpFile, $folderUpload . $gambarBaru)) {
                    $gambar = $gambarBaru;
                } else {
                    $pesan = "Gagal menyimpan gambar baru.";
                }
            }
        }
    }

    if ($pesan === "") {
        $queryUpdate = mysqli_query($conn, "
            UPDATE buku SET
                judul = '$judul',
                penulis = '$penulis',
                kategori = '$kategori',
                harga = '$harga',
                stok = '$stok',
                deskripsi = '$deskripsi',
                gambar = '$gambar'
            WHERE id_buku = $id
        ");

        if ($queryUpdate) {
            if ($gambar !== $buku['gambar'] && !empty($buku['gambar'])) {
                $gambarLama = '../uploads/' . $buku['gambar'];

                if (file_exists($gambarLama)) {
                    unlink($gambarLama);
                }
            }

            header("Location: buku.php?pesan=diubah");
            exit;
        } else {
            if ($gambar !== $buku['gambar']) {
                unlink('../uploads/' . $gambar);
            }

            $pesan = "Gagal memperbarui data buku.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Buku - LITERA</title>
    <link rel="stylesheet" href="../style.css?v=16">
</head>
<body>

<header class="navbar">
    <a href="../index.php" class="logo">LITERA<span>.</span></a>

    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="buku.php">Kelola Buku</a>
        <a href="pesanan.php">Pesanan</a>
    </nav>

    <div class="nav-button">
        <a href="logout.php" class="btn-primary">Keluar</a>
    </div>
</header>

<main class="book-form-page">

    <div class="book-form-heading">
        <p class="eyebrow">PENGELOLAAN KOLEKSI</p>
        <h1>Edit Buku</h1>
        <p>Perbarui informasi buku dalam koleksi LITERA.</p>
    </div>

    <form method="POST" enctype="multipart/form-data" class="book-form-card">

        <?php if ($pesan): ?>
            <div class="form-error">
                <?= htmlspecialchars($pesan); ?>
            </div>
        <?php endif; ?>

        <div class="book-form-grid">

            <div class="book-form-group">
                <label>Judul Buku</label>
                <input type="text" name="judul"
                    value="<?= htmlspecialchars($buku['judul']); ?>" required>
            </div>

            <div class="book-form-group">
                <label>Penulis</label>
                <input type="text" name="penulis"
                    value="<?= htmlspecialchars($buku['penulis']); ?>" required>
            </div>

            <div class="book-form-group">
                <label>Kategori</label>
                <select name="kategori" required>
                    <option value="Novel" <?= $buku['kategori'] == 'Novel' ? 'selected' : ''; ?>>Novel</option>
                    <option value="Bisnis" <?= $buku['kategori'] == 'Bisnis' ? 'selected' : ''; ?>>Bisnis</option>
                    <option value="Pengembangan Diri" <?= $buku['kategori'] == 'Pengembangan Diri' ? 'selected' : ''; ?>>Pengembangan Diri</option>
                </select>
            </div>

            <div class="book-form-group">
                <label>Harga Buku</label>
                <input type="number" name="harga" min="1"
                    value="<?= htmlspecialchars($buku['harga']); ?>" required>
            </div>

            <div class="book-form-group">
                <label>Stok Buku</label>
                <input type="number" name="stok" min="0"
                    value="<?= htmlspecialchars($buku['stok']); ?>" required>
            </div>

            <div class="book-form-group full-width">
                <label>Deskripsi Buku</label>
                <textarea name="deskripsi" rows="5" required><?= htmlspecialchars($buku['deskripsi']); ?></textarea>
            </div>

            <div class="book-form-group full-width">
                <label>Cover Buku Saat Ini</label>

                <?php if (!empty($buku['gambar'])): ?>
                    <img src="../uploads/<?= htmlspecialchars($buku['gambar']); ?>"
                         alt="Cover buku"
                         style="width: 100px; height: 135px; object-fit: cover; border-radius: 8px;">
                <?php endif; ?>

                <label>Ganti Cover Buku (Opsional)</label>
                <input type="file" name="gambar" accept=".jpg,.jpeg,.png,.webp">
                <small>Format JPG, JPEG, PNG, atau WEBP. Maksimal 2 MB.</small>
            </div>

        </div>

        <div class="book-form-actions">
            <a href="buku.php" class="btn-cancel">Batal</a>
            <button type="submit" name="update" class="btn-primary">Simpan Perubahan</button>
        </div>

    </form>

</main>

</body>
</html>