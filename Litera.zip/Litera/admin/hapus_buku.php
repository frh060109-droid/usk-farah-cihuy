<?php
require_once '../koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: buku.php");
    exit;
}

$id = (int) $_GET['id'];

$query = mysqli_query($conn, "SELECT gambar FROM buku WHERE id_buku = $id");
$buku = mysqli_fetch_assoc($query);

if (!$buku) {
    header("Location: buku.php");
    exit;
}

$hapus = mysqli_query($conn, "DELETE FROM buku WHERE id_buku = $id");

if ($hapus) {
    if (!empty($buku['gambar'])) {
        $gambar = '../uploads/' . $buku['gambar'];

        if (file_exists($gambar)) {
            unlink($gambar);
        }
    }

    header("Location: buku.php?pesan=dihapus");
    exit;
}

header("Location: buku.php?pesan=gagal");
exit;
?>