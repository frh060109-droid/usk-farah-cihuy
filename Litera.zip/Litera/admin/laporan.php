
<?php
require_once '../koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Ringkasan penjualan dari pesanan yang selesai
$ringkasan = mysqli_query($conn, "
    SELECT
        COUNT(*) AS jumlah_pesanan,
        COALESCE(SUM(total), 0) AS total_penjualan
    FROM pesanan
    WHERE status = 'Selesai'
");

if (!$ringkasan) {
    die("Gagal mengambil laporan: " . mysqli_error($conn));
}

$data_ringkasan = mysqli_fetch_assoc($ringkasan);

// Daftar transaksi selesai
$query = mysqli_query($conn, "
    SELECT pesanan.*, users.nama, users.email
    FROM pesanan
    LEFT JOIN users ON pesanan.id_user = users.id_user
    WHERE pesanan.status = 'Selesai'
    ORDER BY pesanan.dibuat_pada DESC
");

if (!$query) {
    die("Gagal mengambil transaksi: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Penjualan - LITERA</title>

    <link rel="stylesheet" href="../style.css?v=109">

    <style>
        .report-page {
            width: 100%;
            padding: 65px 35px;
            box-sizing: border-box;
        }

        .report-container {
            width: 100%;
            max-width: 1250px;
            margin: 0 auto;
        }

        .report-heading {
            text-align: center;
            margin-bottom: 45px;
        }

        .report-heading span {
            color: #9b82b8;
            font-size: 14px;
            font-weight: bold;
            letter-spacing: 3px;
        }

        .report-heading h1 {
            color: #493b59;
            font-family: Georgia, serif;
            font-size: 46px;
            margin: 15px 0;
        }

        .report-heading p {
            color: #81718f;
            font-size: 16px;
        }

        .report-summary {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 25px;
            margin-bottom: 35px;
        }

        .summary-card {
            background: #eee5f8;
            border: 1px solid #e0d2ed;
            border-radius: 12px;
            padding: 28px 30px;
        }

        .summary-card p {
            color: #80639e;
            font-size: 15px;
            margin: 0 0 12px;
        }

        .summary-card h2 {
            color: #493b59;
            font-family: Georgia, serif;
            font-size: 32px;
            margin: 0;
        }

        .report-card {
            background: #fdfaff;
            border: 1px solid #e0d2ed;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 8px 25px rgba(91, 68, 117, 0.08);
        }

        .report-card h2 {
            color: #493b59;
            font-family: Georgia, serif;
            font-size: 25px;
            margin: 0 0 25px;
        }

        .report-table-scroll {
            width: 100%;
            overflow-x: auto;
        }

        .report-table {
            width: 100%;
            min-width: 850px;
            border-collapse: collapse;
        }

        .report-table th {
            background: #d9c8eb;
            color: #493b59;
            padding: 18px 15px;
            text-align: center;
            font-size: 14px;
        }

        .report-table td {
            padding: 20px 15px;
            text-align: center;
            color: #71617f;
            border-bottom: 1px solid #eee5f5;
            font-size: 14px;
        }

        .report-table td strong {
            color: #493b59;
        }

        .report-status {
            display: inline-block;
            padding: 7px 14px;
            background: #eee5f8;
            color: #80639e;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }

        .report-detail {
            display: inline-block;
            padding: 9px 16px;
            background: #b69bd3;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 13px;
            font-weight: bold;
        }

        .report-detail:hover {
            background: #9e80c0;
        }

        .report-empty {
            padding: 40px !important;
            color: #9685a5 !important;
        }

        @media (max-width: 768px) {
            .report-page {
                padding: 40px 15px;
            }

            .report-heading h1 {
                font-size: 36px;
            }

            .report-summary {
                grid-template-columns: 1fr;
            }

            .report-card {
                padding: 18px;
            }
        }
    </style>
</head>

<body>

<header class="navbar">
    <a href="../index.php" class="logo">LITERA<span>.</span></a>

    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="buku.php">Kelola Buku</a>
        <a href="pesanan.php">Pesanan</a>
        <a href="pengguna.php">Pengguna</a>
        <a href="laporan.php">Laporan</a>
    </nav>
</header>

<main class="report-page">
    <div class="report-container">

        <div class="report-heading">
            <span>PENGELOLAAN TOKO</span>
            <h1>Laporan Penjualan</h1>
            <p>Ringkasan dan riwayat transaksi penjualan LITERA.</p>
        </div>

        <div class="report-summary">

            <div class="summary-card">
                <p>Total Penjualan</p>
                <h2>
                    Rp<?= number_format($data_ringkasan['total_penjualan'], 0, ',', '.'); ?>
                </h2>
            </div>

            <div class="summary-card">
                <p>Pesanan Selesai</p>
                <h2>
                    <?= number_format($data_ringkasan['jumlah_pesanan']); ?> Pesanan
                </h2>
            </div>

        </div>

        <div class="report-card">
            <h2>Riwayat Transaksi</h2>

            <div class="report-table-scroll">
                <table class="report-table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode Pesanan</th>
                            <th>Pelanggan</th>
                            <th>Tanggal</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Detail</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php if (mysqli_num_rows($query) > 0): ?>

                            <?php $no = 1; ?>

                            <?php while ($pesanan = mysqli_fetch_assoc($query)): ?>
                                <tr>
                                    <td><?= $no++; ?></td>

                                    <td>
                                        <strong>
                                            <?= htmlspecialchars($pesanan['kode_pesanan']); ?>
                                        </strong>
                                    </td>

                                    <td>
                                        <?= htmlspecialchars($pesanan['nama'] ?? '-'); ?>
                                    </td>

                                    <td>
                                        <?= date('d/m/Y', strtotime($pesanan['dibuat_pada'])); ?>
                                    </td>

                                    <td>
                                        <strong>
                                            Rp<?= number_format($pesanan['total'], 0, ',', '.'); ?>
                                        </strong>
                                    </td>

                                    <td>
                                        <span class="report-status">Selesai</span>
                                    </td>

                                    <td>
                                        <a
                                            href="detail_pesanan.php?id=<?= $pesanan['id_pesanan']; ?>"
                                            class="report-detail">
                                            Lihat Detail
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>

                        <?php else: ?>

                            <tr>
                                <td colspan="7" class="report-empty">
                                    Belum ada transaksi yang selesai.
                                </td>
                            </tr>

                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</main>

</body>
</html>
