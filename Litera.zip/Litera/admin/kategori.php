
<?php
require_once '../koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Buat tabel kategori jika belum ada
mysqli_query($conn, "
    CREATE TABLE IF NOT EXISTS kategori (
        id_kategori INT AUTO_INCREMENT PRIMARY KEY,
        nama_kategori VARCHAR(100) NOT NULL UNIQUE
    )
");

// Masukkan kategori lama dari tabel buku
mysqli_query($conn, "
    INSERT IGNORE INTO kategori (nama_kategori)
    SELECT DISTINCT TRIM(kategori)
    FROM buku
    WHERE kategori IS NOT NULL AND TRIM(kategori) != ''
");

$pesan = '';
$jenis = '';

// Tambah kategori
if (isset($_POST['tambah'])) {
    $nama = trim($_POST['nama_kategori']);

    if ($nama === '') {
        $pesan = 'Nama kategori tidak boleh kosong.';
        $jenis = 'error';
    } else {
        $stmt = mysqli_prepare($conn, "
            INSERT INTO kategori (nama_kategori) VALUES (?)
        ");

        mysqli_stmt_bind_param($stmt, "s", $nama);

        if (mysqli_stmt_execute($stmt)) {
            header("Location: kategori.php?pesan=tambah");
            exit;
        } else {
            $pesan = 'Kategori sudah tersedia atau gagal ditambahkan.';
            $jenis = 'error';
        }
    }
}

// Ubah kategori
if (isset($_POST['ubah'])) {
    $id = (int) $_POST['id_kategori'];
    $nama = trim($_POST['nama_kategori']);

    if ($nama === '') {
        $pesan = 'Nama kategori tidak boleh kosong.';
        $jenis = 'error';
    } else {
        mysqli_begin_transaction($conn);

        try {
            $stmt = mysqli_prepare($conn, "
                SELECT nama_kategori FROM kategori
                WHERE id_kategori = ?
            ");
            mysqli_stmt_bind_param($stmt, "i", $id);
            mysqli_stmt_execute($stmt);

            $lama = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

            if (!$lama) {
                throw new Exception('Kategori tidak ditemukan.');
            }

            $namaLama = $lama['nama_kategori'];

            $stmt = mysqli_prepare($conn, "
                UPDATE kategori SET nama_kategori = ?
                WHERE id_kategori = ?
            ");
            mysqli_stmt_bind_param($stmt, "si", $nama, $id);

            if (!mysqli_stmt_execute($stmt)) {
                throw new Exception('Nama kategori sudah digunakan.');
            }

            // Perbarui kategori pada buku yang menggunakan nama lama
            $stmt = mysqli_prepare($conn, "
                UPDATE buku SET kategori = ?
                WHERE kategori = ?
            ");
            mysqli_stmt_bind_param($stmt, "ss", $nama, $namaLama);

            if (!mysqli_stmt_execute($stmt)) {
                throw new Exception('Gagal memperbarui kategori buku.');
            }

            mysqli_commit($conn);

            header("Location: kategori.php?pesan=ubah");
            exit;

        } catch (Exception $e) {
            mysqli_rollback($conn);
            $pesan = $e->getMessage();
            $jenis = 'error';
        }
    }
}

// Hapus kategori
if (isset($_GET['hapus'])) {
    $id = (int) $_GET['hapus'];

    $stmt = mysqli_prepare($conn, "
        SELECT nama_kategori FROM kategori
        WHERE id_kategori = ?
    ");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);

    $kategori = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if ($kategori) {
        $stmt = mysqli_prepare($conn, "
            SELECT COUNT(*) AS jumlah FROM buku
            WHERE kategori = ?
        ");

        mysqli_stmt_bind_param($stmt, "s", $kategori['nama_kategori']);
        mysqli_stmt_execute($stmt);

        $jumlah = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

        if ($jumlah['jumlah'] > 0) {
            header("Location: kategori.php?pesan=dipakai");
            exit;
        }

        $stmt = mysqli_prepare($conn, "
            DELETE FROM kategori WHERE id_kategori = ?
        ");

        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
    }

    header("Location: kategori.php?pesan=hapus");
    exit;
}

// Notifikasi
if (isset($_GET['pesan'])) {
    $notifikasi = [
        'tambah' => 'Kategori berhasil ditambahkan.',
        'ubah' => 'Kategori berhasil diperbarui.',
        'hapus' => 'Kategori berhasil dihapus.',
        'dipakai' => 'Kategori tidak bisa dihapus karena masih digunakan oleh buku.'
    ];

    $pesan = $notifikasi[$_GET['pesan']] ?? '';
    $jenis = 'info';
}

// Ambil semua kategori
$query = mysqli_query($conn, "
    SELECT * FROM kategori ORDER BY nama_kategori ASC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Kategori - LITERA</title>
    <link rel="stylesheet" href="../style.css?v=14">

    <style>
        .category-management {
            max-width: 850px;
            margin: 35px auto;
            padding: 25px;
            background: #fff;
            border-radius: 12px;
        }

        .category-form {
            display: flex;
            gap: 10px;
            margin: 20px 0;
        }

        .category-form input {
            flex: 1;
            min-width: 0;
            padding: 13px;
            border: 1px solid #ddd;
            border-radius: 7px;
        }

        .category-form button {
            border: none;
            cursor: pointer;
        }

        .category-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .category-table th,
        .category-table td {
            padding: 14px 12px;
            border-bottom: 1px solid #eee;
            text-align: left;
        }

        .category-table th {
            background: #f5eef9;
        }

        .category-edit {
            display: flex;
            gap: 7px;
            flex-wrap: wrap;
        }

        .category-edit input {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
            min-width: 100px;
        }

        .category-edit button {
            padding: 8px 12px;
            border: none;
            border-radius: 5px;
            background: #b69bd3;
            color: white;
            cursor: pointer;
        }

        .category-delete {
            color: #b34e4e;
            text-decoration: none;
            font-size: 13px;
        }

        .category-message {
            padding: 12px;
            background: #f5eef9;
            border-radius: 7px;
            margin: 15px 0;
            font-size: 13px;
        }

        .category-error {
            background: #fff0f0;
            color: #a33;
        }

        @media(max-width: 550px) {
            .category-management {
                padding: 15px;
            }

            .category-form {
                flex-direction: column;
            }

            .category-table th,
            .category-table td {
                padding: 10px 6px;
                font-size: 12px;
            }
        }
    </style>
</head>

<body>

<header class="navbar">
    <a href="../index.php" class="logo">LITERA<span>.</span></a>

    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="buku.php">Kelola Buku</a>
        <a href="kategori.php">Kelola Kategori</a>
        <a href="pesanan.php">Pesanan</a>
    </nav>

    <div class="nav-button">
        <a href="logout.php" class="btn-primary">Keluar</a>
    </div>
</header>

<main class="admin-page">

    <section class="admin-heading">
        <p class="eyebrow">PENGELOLAAN KOLEKSI</p>
        <h1>Kelola <span>Kategori.</span></h1>
        <p>Tambahkan dan atur kategori buku LITERA.</p>
    </section>

    <section class="category-management">

        <h2>Tambah Kategori</h2>
        <p>Masukkan nama kategori baru.</p>

        <?php if ($pesan !== ''): ?>
            <div class="category-message <?= $jenis === 'error' ? 'category-error' : ''; ?>">
                <?= htmlspecialchars($pesan); ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="category-form">
            <input
                type="text"
                name="nama_kategori"
                placeholder="Contoh: Pendidikan"
                maxlength="100"
                required
            >

            <button type="submit" name="tambah" class="btn-primary">
                + Tambah Kategori
            </button>
        </form>

        <hr>

        <h2 style="margin-top:25px;">Daftar Kategori</h2>

        <div style="overflow-x:auto;">
            <table class="category-table">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Nama Kategori</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (mysqli_num_rows($query) > 0): ?>
                        <?php $no = 1; ?>

                        <?php while ($kategori = mysqli_fetch_assoc($query)): ?>
                            <tr>
                                <td><?= $no++; ?></td>

                                <td>
                                    <form method="POST" class="category-edit">
                                        <input
                                            type="hidden"
                                            name="id_kategori"
                                            value="<?= $kategori['id_kategori']; ?>"
                                        >

                                        <input
                                            type="text"
                                            name="nama_kategori"
                                            value="<?= htmlspecialchars($kategori['nama_kategori']); ?>"
                                            maxlength="100"
                                            required
                                        >

                                        <button type="submit" name="ubah">
                                            Simpan
                                        </button>
                                    </form>
                                </td>

                                <td>
                                    <a
                                        href="kategori.php?hapus=<?= $kategori['id_kategori']; ?>"
                                        class="category-delete"
                                        onclick="return confirm('Yakin ingin menghapus kategori ini?')"
                                    >
                                        Hapus
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>

                    <?php else: ?>
                        <tr>
                            <td colspan="3" style="text-align:center;">
                                Belum ada kategori.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <a href="buku.php" class="btn-primary" style="display:inline-block; margin-top:25px;">
            Kembali ke Kelola Buku
        </a>

    </section>

</main>

<footer>
    <a href="../index.php" class="logo">LITERA<span>.</span></a>
    <p>Temukan cerita, ciptakan kenangan.</p>
    <small>© 2026 LITERA. Semua hak dilindungi.</small>
</footer>

</body>
</html>
