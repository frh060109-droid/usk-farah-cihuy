```php
<?php
require_once '../koneksi.php';

if (!isset($_SESSION['id_user']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$query = mysqli_query($conn, "
    SELECT
        u.id_user,
        u.nama,
        MAX(c.tanggal_kirim) AS pesan_terakhir,
        SUM(CASE
            WHEN c.pengirim = 'user' AND c.dibaca = 0 THEN 1
            ELSE 0
        END) AS belum_dibaca
    FROM users u
    INNER JOIN chat_pesan c ON u.id_user = c.id_user
    GROUP BY u.id_user, u.nama
    ORDER BY pesan_terakhir DESC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesan Pengguna - LITERA</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        .pesan-admin {
            max-width: 900px;
            margin: 40px auto;
            padding: 20px;
        }

        .daftar-pesan {
            background: white;
            padding: 20px;
            border-radius: 12px;
            margin-top: 20px;
            box-shadow: 0 3px 15px rgba(0,0,0,.05);
        }

        .item-pesan {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            padding: 17px 5px;
            border-bottom: 1px solid #eee;
        }

        .item-pesan:last-child {
            border-bottom: none;
        }

        .item-pesan a {
            text-decoration: none;
            color: #947ba9;
            font-weight: bold;
        }

        .jumlah-pesan {
            color: #a85e5e;
            font-size: 13px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<header class="navbar">
    <a href="dashboard.php" class="logo">LITERA<span>.</span></a>
    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="buku.php">Kelola Buku</a>
        <a href="pesanan.php">Pesanan</a>
        <a href="pesan.php">Pesan Pengguna</a>
    </nav>
    <div class="nav-button">
        <a href="../logout.php" class="btn-primary">Keluar</a>
    </div>
</header>

<main class="pesan-admin">
    <h2>Pesan Pengguna</h2>
    <p>Lihat dan balas pesan dari pengguna LITERA.</p>

    <div class="daftar-pesan">
        <?php if ($query && mysqli_num_rows($query) > 0): ?>

            <?php while ($row = mysqli_fetch_assoc($query)): ?>
                <div class="item-pesan">
                    <div>
                        <strong><?= htmlspecialchars($row['nama']); ?></strong>
                        <p style="font-size:12px;color:#999;margin-top:5px;">
                            Pesan terakhir:
                            <?= date('d/m/Y H:i', strtotime($row['pesan_terakhir'])); ?>
                        </p>
                        <?php if ($row['belum_dibaca'] > 0): ?>
                            <span class="jumlah-pesan">
                                <?= $row['belum_dibaca']; ?> pesan baru
                            </span>
                        <?php endif; ?>
                    </div>

                    <a href="chat_admin.php?id=<?= $row['id_user']; ?>">
                        Buka Chat →
                    </a>
                </div>
            <?php endwhile; ?>

        <?php else: ?>
            <p style="text-align:center;color:#999;">
                Belum ada pesan dari pengguna.
            </p>
        <?php endif; ?>
    </div>
</main>

</body>
</html>
```