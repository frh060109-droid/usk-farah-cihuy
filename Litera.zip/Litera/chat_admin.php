
<?php
require_once 'koneksi.php';

if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit;
}

if ($_SESSION['role'] === 'admin') {
    header("Location: admin/pesan.php");
    exit;
}

$id_user = (int) $_SESSION['id_user'];

// Ambil pesan dan tandai balasan admin sudah dibaca
if (isset($_GET['ambil'])) {
    mysqli_query($conn, "
        UPDATE chat_pesan
        SET dibaca = 1
        WHERE id_user = $id_user
        AND pengirim = 'admin'
    ");

    $result = mysqli_query($conn, "
        SELECT id_pesan, pengirim, isi_pesan, tanggal_kirim
        FROM chat_pesan
        WHERE id_user = $id_user
        ORDER BY id_pesan ASC
    ");

    $data = [];

    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }

    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

// Kirim pesan
if (isset($_POST['kirim'])) {
    $isi = trim($_POST['isi_pesan']);

    if ($isi !== '') {
        $stmt = mysqli_prepare($conn, "
            INSERT INTO chat_pesan
            (id_user, pengirim, isi_pesan)
            VALUES (?, 'user', ?)
        ");

        mysqli_stmt_bind_param($stmt, "is", $id_user, $isi);
        mysqli_stmt_execute($stmt);
    }

    header("Location: chat_admin.php");
    exit;
}

// Tandai balasan yang sudah tampil sebagai dibaca
mysqli_query($conn, "
    UPDATE chat_pesan
    SET dibaca = 1
    WHERE id_user = $id_user
    AND pengirim = 'admin'
");

$query = mysqli_query($conn, "
    SELECT id_pesan, pengirim, isi_pesan, tanggal_kirim
    FROM chat_pesan
    WHERE id_user = $id_user
    ORDER BY id_pesan ASC
");

$nama = $_SESSION['nama'] ?? 'Pengguna';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat Admin - LITERA</title>
    <link rel="stylesheet" href="style.css?v=15">

    <style>
        .chat-page {
            max-width: 850px;
            margin: 45px auto;
            padding: 20px;
        }

        .chat-container {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 25px rgba(0,0,0,.06);
        }

        .chat-header {
            padding: 22px;
            background: #947ba9;
            color: white;
        }

        .chat-header h2 {
            margin-bottom: 5px;
        }

        .chat-body {
            height: 430px;
            overflow-y: auto;
            padding: 22px;
            background: #faf7fc;
        }

        .chat-message {
            display: flex;
            margin-bottom: 15px;
        }

        .chat-message.user {
            justify-content: flex-end;
        }

        .chat-bubble {
            max-width: 75%;
            padding: 12px 16px;
            border-radius: 13px;
            background: white;
            color: #51465a;
            overflow-wrap: anywhere;
            box-shadow: 0 2px 7px rgba(0,0,0,.04);
        }

        .chat-message.user .chat-bubble {
            background: #e9dff2;
        }

        .chat-time {
            display: block;
            margin-top: 7px;
            font-size: 10px;
            color: #8c8193;
        }

        .chat-form {
            display: flex;
            gap: 10px;
            padding: 18px;
            border-top: 1px solid #eee;
        }

        .chat-form textarea {
            flex: 1;
            min-width: 0;
            height: 48px;
            padding: 13px;
            border: 1px solid #ddd;
            border-radius: 9px;
            resize: none;
            font-family: inherit;
        }

        .chat-form button {
            border: none;
            cursor: pointer;
        }

        @media(max-width: 600px) {
            .chat-form {
                flex-direction: column;
            }

            .chat-form button {
                width: 100%;
            }
        }
    </style>
</head>

<body>

<header class="navbar">
    <a href="index.php" class="logo">LITERA<span>.</span></a>

    <nav>
        <a href="index.php">Beranda</a>
        <a href="katalog.php">Katalog</a>
        <a href="index.php#tentang">Tentang</a>
        <a href="chat_admin.php">Contact Admin</a>
    </nav>

    <div class="nav-button">
        <a href="profile.php" class="btn-outline">Profil</a>
        <a href="logout.php" class="btn-primary">Keluar</a>
    </div>
</header>

<main class="chat-page">

    <p class="eyebrow">LAYANAN PELANGGAN LITERA</p>

    <div class="chat-container">

        <div class="chat-header">
            <h2>Chat Admin LITERA</h2>
            <p>Silakan sampaikan pertanyaan atau kendala kamu.</p>
        </div>

        <div class="chat-body" id="chatBody">

            <?php while ($row = mysqli_fetch_assoc($query)): ?>

                <div class="chat-message <?= $row['pengirim'] === 'user' ? 'user' : 'admin'; ?>">
                    <div class="chat-bubble">
                        <?= nl2br(htmlspecialchars($row['isi_pesan'])); ?>

                        <span class="chat-time">
                            <?= date('d/m/Y H:i', strtotime($row['tanggal_kirim'])); ?>
                            · <?= $row['pengirim'] === 'user' ? 'Kamu' : 'Admin'; ?>
                        </span>
                    </div>
                </div>

            <?php endwhile; ?>

            <?php if (mysqli_num_rows($query) === 0): ?>
                <p style="text-align:center;color:#999;">
                    Belum ada percakapan. Kirim pesan pertamamu!
                </p>
            <?php endif; ?>

        </div>

        <form method="POST" class="chat-form">

            <textarea name="isi_pesan"
                      placeholder="Tulis pesan..."
                      required></textarea>

            <button type="submit" name="kirim" class="btn-primary">
                Kirim
            </button>

        </form>

    </div>

</main>

<script>
const chatBody = document.getElementById('chatBody');
let pesanTerakhir = '';

function ambilPesan() {
    fetch('chat_admin.php?ambil=1')
        .then(response => response.json())
        .then(data => {
            const versi = JSON.stringify(data);

            if (versi === pesanTerakhir) return;

            pesanTerakhir = versi;
            chatBody.innerHTML = '';

            if (data.length === 0) {
                chatBody.innerHTML =
                    '<p style="text-align:center;color:#999;">Belum ada percakapan. Kirim pesan pertamamu!</p>';
            }

            data.forEach(pesan => {
                const baris = document.createElement('div');
                baris.className = 'chat-message ' +
                    (pesan.pengirim === 'user' ? 'user' : 'admin');

                const bubble = document.createElement('div');
                bubble.className = 'chat-bubble';

                const isi = document.createElement('div');
                isi.textContent = pesan.isi_pesan;

                const waktu = document.createElement('span');
                waktu.className = 'chat-time';
                waktu.textContent = pesan.tanggal_kirim +
                    ' · ' + (pesan.pengirim === 'user' ? 'Kamu' : 'Admin');

                bubble.appendChild(isi);
                bubble.appendChild(waktu);
                baris.appendChild(bubble);
                chatBody.appendChild(baris);
            });

            chatBody.scrollTop = chatBody.scrollHeight;
        })
        .catch(error => console.log(error));
}

chatBody.scrollTop = chatBody.scrollHeight;
ambilPesan();
setInterval(ambilPesan, 3000);
</script>

</body>
</html>
