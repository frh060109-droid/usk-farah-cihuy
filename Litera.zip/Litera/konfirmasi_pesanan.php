
<?php
require_once 'koneksi.php';

if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['id_pesanan'])) {
    header("Location: riwayat.php");
    exit;
}

$id_pesanan = (int) $_POST['id_pesanan'];
$id_user = (int) $_SESSION['id_user'];

$stmt = mysqli_prepare($conn, "
    UPDATE pesanan
    SET status = 'Selesai'
    WHERE id_pesanan = ?
    AND id_user = ?
    AND status = 'Diantar'
");

mysqli_stmt_bind_param($stmt, "ii", $id_pesanan, $id_user);
mysqli_stmt_execute($stmt);
mysqli_stmt_close($stmt);

header("Location: riwayat.php");
exit;
?>
